// ============ ЛОГИКА УЛУЧШЕНИЙ ============
function getUpgradeLevel(name) { return upgrades[name] ? upgrades[name].level : 0; }
function isUpgradeActive(name) {
    if (!upgrades[name]) return false;
    if (!upgrades[name].active) return false;
    return upgrades[name].level > 0;
}
function getNextCost(name) {
    const def = UPGRADE_DEFS[name];
    if (!def) return null;
    const lvl = getUpgradeLevel(name);
    if (lvl >= def.maxLevel) return null;
    return def.costs[lvl + 1];
}
function canUpgrade(name) {
    const cost = getNextCost(name);
    return cost !== null && starsBalance >= cost;
}

function getLightningBoostValue() {
    if (!isUpgradeActive('lightningBoost')) return 0;
    const lvl = getUpgradeLevel('lightningBoost');
    return [0, 0.10, 0.15, 0.25][lvl] || 0;
}
function getGoldFeverChance() {
    if (!isUpgradeActive('goldFever')) return 0;
    const lvl = getUpgradeLevel('goldFever');
    return [0, 0.15, 0.20, 0.30, 0.40][lvl] || 0;
}
function getAutomatikaLevel() {
    return isUpgradeActive('automatika') ? getUpgradeLevel('automatika') : 0;
}
function getMagazineSize() {
    const lvl = getAutomatikaLevel();
    if (lvl === 1) return 15;
    if (lvl === 2) return 35;
    if (lvl === 3) return 60;
    return 0;
}
function getReloadDuration() {
    const lvl = getAutomatikaLevel();
    if (lvl === 3) return 2500;
    if (lvl >= 1) return 1500;
    return 300;
}
function getFireDelay() {
    const lvl = getAutomatikaLevel();
    if (lvl === 3) return 33;   // миниган: ~30 выстрелов/сек
    if (lvl === 2) return 110;  // пулемёт: ~9 выстрелов/сек
    return 0;                    // пистолет/полуавтомат: по клику
}
function canUseAutoMode() { return getAutomatikaLevel() >= 2; }
function isAlwaysAuto() { return getAutomatikaLevel() === 3; }

function tryUpgrade(name) {
    const cost = getNextCost(name);
    if (cost === null) return false;
    if (starsBalance < cost) { hint(t('insufficient')); return false; }
    starsBalance -= cost;
    upgrades[name].level = getUpgradeLevel(name) + 1;
    upgrades[name].active = true;
    saveState();
    updateStarsDisplay();
    updateUpgradesUI();
    if (name === 'automatika' && upgrades[name].level === 1) {
        unlockAchievement('automation');
    }
    return true;
}
function toggleUpgrade(name) {
    if (!upgrades[name]) return;
    if (upgrades[name].level <= 0) return;
    upgrades[name].active = !upgrades[name].active;
    saveState();
    updateUpgradesUI();
}
function addBonusStars(a) { starsBalance += a; saveState(); updateStarsDisplay(); updateUpgradesUI(); }

// ============ ДОСТИЖЕНИЯ ============
function unlockAchievement(id) {
    if (achievements[id]) return;
    const def = ACHIEVEMENTS.find(a => a.id === id);
    if (!def) return;
    achievements[id] = true;
    saveState();
    updateAchievementsUI();
    showAchievementToast(def);
}

let achToastTimeout = null;
function showAchievementToast(def) {
    const toast = document.getElementById('achToast');
    const toastIcon = document.getElementById('achToastIcon');
    const toastName = document.getElementById('achToastName');
    if (!toast) return;
    toastIcon.innerHTML = svgIcon(def.icon);
    toastName.textContent = def.name[lang] || def.name.ru;
    toast.classList.add('show');
    if (achToastTimeout) clearTimeout(achToastTimeout);
    achToastTimeout = setTimeout(() => toast.classList.remove('show'), 3800);
}

// Всплывающая подсказка (замена alert)
let hintTimeout = null;
function hint(msg) {
    let el = document.getElementById('hintToast');
    if (!el) {
        el = document.createElement('div');
        el.id = 'hintToast';
        el.className = 'hint-toast';
        document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add('show');
    if (hintTimeout) clearTimeout(hintTimeout);
    hintTimeout = setTimeout(() => el.classList.remove('show'), 1800);
}

function updateAchievementsUI() {
    const list = document.getElementById('achList');
    const counter = document.getElementById('achCount');
    const total = document.getElementById('achTotal');
    if (!list) return;
    const totalCount = ACHIEVEMENTS.length;
    let unlocked = 0;
    list.innerHTML = '';
    ACHIEVEMENTS.forEach(a => {
        const unlockedFlag = !!achievements[a.id];
        if (unlockedFlag) unlocked++;
        const div = document.createElement('div');
        div.className = 'ach-item' + (unlockedFlag ? ' unlocked' : '');
        div.innerHTML =
            '<div class="ach-icon">' + svgIcon(a.icon) + '</div>' +
            '<div class="ach-info">' +
                '<div class="ach-name">' + (a.name[lang] || a.name.ru) + '</div>' +
                '<div class="ach-desc">' + (a.desc[lang] || a.desc.ru) + '</div>' +
            '</div>';
        list.appendChild(div);
    });
    if (counter) counter.textContent = unlocked;
    if (total) total.textContent = totalCount;
}

// ============ DOM ============
const container = document.getElementById('threeContainer');
const hud = document.getElementById('hud');
const hudTime = document.getElementById('hudTime');
const hudScore = document.getElementById('hudScore');
const hudLives = document.getElementById('hudLives');
const playBtn = document.getElementById('playBtn');
const settingsBtn = document.getElementById('settingsBtn');
const upgradesBtn = document.getElementById('upgradesBtn');
const achievementsBtn = document.getElementById('achievementsBtn');
const upgradesOverlay = document.getElementById('upgradesOverlay');
const upgradesClose = document.getElementById('upgradesClose');
const achievementsOverlay = document.getElementById('achievementsOverlay');
const achievementsClose = document.getElementById('achievementsClose');
const settingsModal = document.getElementById('settingsModal');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const resetProgressBtn = document.getElementById('resetProgressBtn');
const durationSelect = document.getElementById('durationSelect');
const livesSelect = document.getElementById('livesSelect');
const difficultySelect = document.getElementById('difficultySelect');
const spawnModeSelect = document.getElementById('spawnModeSelect');
const graphicsQualitySelect = document.getElementById('graphicsQualitySelect');
const langSelect = document.getElementById('langSelect');
const modeSelect = document.getElementById('modeSelect');
const modeBack = document.getElementById('modeBack');
const classicBtn = document.getElementById('classicBtn');
const levelBtn = document.getElementById('levelBtn');
const levelsMenu = document.getElementById('levelsMenu');
const levelsBack = document.getElementById('levelsBack');
const level1Card = document.getElementById('level1Card');
const level2Card = document.getElementById('level2Card');
const level3Card = document.getElementById('level3Card');
const level1Status = document.getElementById('level1Status');
const level2Status = document.getElementById('level2Status');
const level3Status = document.getElementById('level3Status');
const levelHud = document.getElementById('levelHud');
const levelTimer = document.getElementById('levelTimer');
const levelExtraInfo = document.getElementById('levelExtraInfo');
const levelResult = document.getElementById('levelResult');
const resultTitle = document.getElementById('resultTitle');
const resultSub = document.getElementById('resultSub');
const resultBtn = document.getElementById('resultBtn');
const menuScore = document.getElementById('menuScore');
const starsDisplay = document.getElementById('starsDisplay');
const tutorialBtn = document.getElementById('tutorialBtn');
const tutorialClose = document.getElementById('tutorialClose');
const tutorialOverlay = document.getElementById('tutorialOverlay');
const bonusOverlay = document.getElementById('bonusOverlay');
const bonusClose = document.getElementById('bonusClose');
const starsCounter = document.getElementById('starsCounter');
const fireModeSwitch = document.getElementById('fireModeSwitch');
const fmLabelSemi = document.getElementById('fmLabelSemi');
const fmLabelAuto = document.getElementById('fmLabelAuto');
const ammoHud = document.getElementById('ammoHud');
const ammoMag = document.getElementById('ammoMag');
const ammoMax = document.getElementById('ammoMax');
const ammoFill = document.getElementById('ammoFill');
const ammoState = document.getElementById('ammoState');
const langRuBtn = document.getElementById('langRu');
const langEnBtn = document.getElementById('langEn');
const renderScaleSelect = document.getElementById('renderScaleSelect');
const fpsSelect = document.getElementById('fpsSelect');
const eballBackendEl = document.getElementById('eballBackend');
const eballWebgpuEl = document.getElementById('eballWebgpu');
const bootLogoEl = document.getElementById('bootLogo');
const bootSubEl = document.getElementById('bootSub');
const bootFillEl = document.getElementById('bootFill');
const bootPctEl = document.getElementById('bootPct');
const bootStepEl = document.getElementById('bootStep');
const bootLogEl = document.getElementById('bootLog');
const deployOverlay = document.getElementById('deployOverlay');
const deployKickerEl = document.getElementById('deployKicker');
const deployTitleEl = document.getElementById('deployTitle');
const deploySubEl = document.getElementById('deploySub');
const deployFillEl = document.getElementById('deployFill');
const deployPctEl = document.getElementById('deployPct');
const deployTipEl = document.getElementById('deployTip');
const fpsHud = document.getElementById('fpsHud');
const fpsValEl = document.getElementById('fpsVal');
const fpsMsEl = document.getElementById('fpsMs');
const fpsScaleEl = document.getElementById('fpsScale');
const logoTitleEl = document.getElementById('logoTitle');
const tbNameEl = document.getElementById('tbName');
const menuFootBrandEl = document.getElementById('menuFootBrand');

// ============ ПРИМЕНЕНИЕ ЛОКАЛИЗАЦИИ ============
function applyI18n() {
    document.documentElement.lang = lang;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        el.textContent = t(el.dataset.i18n);
    });
    if (langRuBtn) langRuBtn.classList.toggle('on', lang === 'ru');
    if (langEnBtn) langEnBtn.classList.toggle('on', lang === 'en');
}
function setLang(l) {
    if (l !== 'ru' && l !== 'en') return;
    if (lang === l) return;
    lang = l;
    saveState();
    applyI18n();
    updateUpgradesUI();
    updateAchievementsUI();
    updateLevelStatuses();
    updateFireModeSwitch();
    updateAmmoHUD();
}

// ============ E-BALL: определение графического бэкенда ============
function fillEballInfo() {
    if (!document.body.classList.contains('eball')) return;
    const s = (typeof GL_RENDERER_STRING !== 'undefined') ? GL_RENDERER_STRING : '';
    let val;
    if (/swiftshader/i.test(s)) val = t('vkSwift');
    else if (/vulkan/i.test(s)) val = t('vkHardware');
    else if (/d3d11|direct3d/i.test(s)) val = t('d3dCompat');
    else val = t('webGlBrowser');
    if (eballBackendEl) eballBackendEl.textContent = val;
    if (eballWebgpuEl) eballWebgpuEl.textContent = (navigator.gpu !== undefined) ? t('webgpuAvail') : t('webgpuNone');
    if (typeof EBALL_GOOSE_MS !== 'undefined' && EBALL_GOOSE_MS !== null) {
        const row = document.getElementById('eballGooseRow');
        if (row) row.style.display = '';
        const gEl = document.getElementById('eballGoose');
        if (gEl) gEl.textContent = tf('gooseOk', { n: EBALL_GOOSE_MS });
    }
}

// ============ UI ============
function updateStarsDisplay() {
    if (starsDisplay) starsDisplay.textContent = starsBalance;
    const upgBal = document.getElementById('starsDisplayUpg');
    if (upgBal) upgBal.textContent = starsBalance;
}

function romanNumeral(n) {
    const map = ['—', 'I', 'II', 'III', 'IV', 'V'];
    return map[n] || '';
}

function updateUpgradesUI() {
    ['lightningBoost', 'goldFever', 'doubleChain', 'automatika'].forEach(name => {
        const def = UPGRADE_DEFS[name];
        const lvl = getUpgradeLevel(name);
        const lvlBadge = document.getElementById('lvl-' + name);
        const desc = document.getElementById('desc-' + name);
        const btn = document.getElementById('btn-' + name);
        const toggle = document.getElementById('toggle-' + name);

        if (!lvlBadge || !btn) return;

        lvlBadge.textContent = romanNumeral(lvl);
        lvlBadge.classList.toggle('max', lvl >= def.maxLevel && lvl > 0);
        lvlBadge.style.display = lvl > 0 ? '' : 'none';

        const dict = def.descriptions[lang] || def.descriptions.ru;
        if (lvl > 0) {
            desc.textContent = dict[lvl];
        } else {
            desc.textContent = dict[1] || dict[0];
        }

        const nextCost = getNextCost(name);
        if (nextCost === null) {
            btn.textContent = t('max');
            btn.className = 'upg-buy max';
            btn.disabled = true;
        } else {
            btn.innerHTML = (lvl === 0 ? t('buy') : t('upgAction')) + ' ' + nextCost + ' ' + svgIcon('star', 'icn-s');
            btn.className = 'upg-buy';
            btn.disabled = false;
            if (starsBalance < nextCost) btn.classList.add('poor');
            else btn.classList.remove('poor');
        }

        if (toggle) {
            if (lvl > 0) {
                toggle.style.display = '';
                toggle.classList.toggle('active', upgrades[name].active);
            } else {
                toggle.style.display = 'none';
                toggle.classList.remove('active');
            }
        }
    });

    updateLevelStatuses();
    updateFireModeSwitch();
}

function updateLevelStatuses() {
    if (level1Status) { level1Status.textContent = level1Completed ? t('passed') : ''; if (level1Card) level1Card.classList.toggle('completed', level1Completed); }
    if (level2Status) { level2Status.textContent = level2Completed ? t('passed') : ''; if (level2Card) level2Card.classList.toggle('completed', level2Completed); }
    if (level3Status) { level3Status.textContent = level3Completed ? t('passed') : ''; if (level3Card) level3Card.classList.toggle('completed', level3Completed); }
}

function updateFireModeSwitch() {
    if (!fireModeSwitch) return;
    const lvl = getAutomatikaLevel();
    const show = lvl === 2;
    fireModeSwitch.classList.toggle('visible', show);
    if (show) {
        fireModeSwitch.classList.toggle('auto', machinegunAutoMode);
        fmLabelSemi.classList.toggle('active', !machinegunAutoMode);
        fmLabelAuto.classList.toggle('active', machinegunAutoMode);
    }
}

// ============ СБРОС ============
const resetOverlay = document.getElementById('resetConfirmOverlay');
const resetYes = document.getElementById('resetConfirmYes');
const resetNo = document.getElementById('resetConfirmNo');
function resetProgress() { resetOverlay.classList.add('active'); }
resetYes.addEventListener('click', () => {
    starsBalance = 0;
    upgrades = {
        lightningBoost: { level: 0, active: true },
        goldFever: { level: 0, active: true },
        doubleChain: { level: 0, active: true },
        automatika: { level: 0, active: true }
    };
    level1Completed = level2Completed = level3Completed = false;
    achievements = {};
    saveState();
    updateStarsDisplay();
    updateUpgradesUI();
    updateAchievementsUI();
    resetOverlay.classList.remove('active');
});
resetNo.addEventListener('click', () => resetOverlay.classList.remove('active'));
resetOverlay.addEventListener('click', e => { if (e.target === resetOverlay) resetOverlay.classList.remove('active'); });

// ============ ИГРОВЫЕ ПЕРЕМЕННЫЕ ============
let gameActive = false, currentStars = 0, timeLeft = settings.duration, lives = settings.lives;
let balls = [], particles = [], projectiles = [];
let spawnTimerId = null, gameTimerId = null, animFrameId = null;
const MAX_BALLS_NORMAL = 8, MAX_BALLS_HARDCORE = 15;
const difficultySettings = {
    easy: { spawnInterval: 1.2, minSpawnInterval: 0.6 },
    medium: { spawnInterval: 0.9, minSpawnInterval: 0.45 },
    hard: { spawnInterval: 0.7, minSpawnInterval: 0.3 }
};

// ============ АУДИО (серьёзный звук) ============
let audioCtx = null, masterGain = null, noiseBuffer = null, musicTimerId = null;
function initAudio() {
    if (!audioCtx) {
        try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return; }
        masterGain = audioCtx.createGain();
        masterGain.gain.value = 0.85;
        masterGain.connect(audioCtx.destination);
        const len = Math.floor(audioCtx.sampleRate * 1.0);
        noiseBuffer = audioCtx.createBuffer(1, len, audioCtx.sampleRate);
        const d = noiseBuffer.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
}
function playTone(f1, f2, type, dur, vol, when) {
    if (!audioCtx) return;
    try {
        const t0 = audioCtx.currentTime + (when || 0);
        const o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.type = type;
        o.frequency.setValueAtTime(Math.max(20, f1), t0);
        o.frequency.exponentialRampToValueAtTime(Math.max(20, f2 || f1), t0 + dur);
        g.gain.setValueAtTime(vol, t0);
        g.gain.exponentialRampToValueAtTime(0.0008, t0 + dur);
        o.connect(g); g.connect(masterGain || audioCtx.destination);
        o.start(t0); o.stop(t0 + dur + 0.02);
    } catch (e) {}
}
function playNoise(dur, vol, filterType, freq, when) {
    if (!audioCtx || !noiseBuffer) return;
    try {
        const t0 = audioCtx.currentTime + (when || 0);
        const src = audioCtx.createBufferSource();
        src.buffer = noiseBuffer;
        src.loop = true;
        const flt = audioCtx.createBiquadFilter();
        flt.type = filterType || 'lowpass';
        flt.frequency.setValueAtTime(Math.max(40, freq || 800), t0);
        const g = audioCtx.createGain();
        g.gain.setValueAtTime(vol, t0);
        g.gain.exponentialRampToValueAtTime(0.0008, t0 + dur);
        src.connect(flt); flt.connect(g); g.connect(masterGain || audioCtx.destination);
        src.start(t0); src.stop(t0 + dur + 0.02);
    } catch (e) {}
}
const sfxShoot = () => {
    playTone(170, 55, 'square', 0.09, 0.16);
    playNoise(0.05, 0.20, 'highpass', 2400);
};
const sfxPop = () => {
    playTone(440, 150, 'sine', 0.12, 0.15);
    playNoise(0.035, 0.07, 'bandpass', 900);
};
const sfxGolden = () => {
    playTone(660, 660, 'triangle', 0.10, 0.09);
    playTone(990, 990, 'triangle', 0.14, 0.07, 0.07);
};
const sfxBomb = () => {
    playTone(95, 30, 'sine', 0.5, 0.30);
    playNoise(0.42, 0.28, 'lowpass', 420);
    playNoise(0.12, 0.10, 'highpass', 2000);
};
const sfxLightning = () => {
    playTone(1900, 130, 'sawtooth', 0.17, 0.12);
    playNoise(0.14, 0.09, 'highpass', 3600);
};
const sfxGameOver = () => {
    playTone(140, 44, 'square', 0.62, 0.22);
    playNoise(0.35, 0.10, 'lowpass', 600);
};
const sfxReload = () => {
    playNoise(0.02, 0.22, 'bandpass', 1900);
    playTone(260, 220, 'square', 0.03, 0.05);
    playNoise(0.02, 0.16, 'bandpass', 1300, 0.14);
    playTone(200, 170, 'square', 0.03, 0.05, 0.14);
};
function startMusic() {
    if (!audioCtx || musicTimerId) return;
    // Минорная тема: A2 C3 E3 C3 | F2 A2 C3 E3 | D3 F3 A3 F3 | E3 C3 G2 E3
    const notes = [110, 130.81, 164.81, 130.81, 87.31, 110, 130.81, 164.81,
                   146.83, 174.61, 220, 174.61, 164.81, 130.81, 98, 164.81];
    let ni = 0;
    function pn() {
        if (!gameActive) return;
        const f = notes[ni % notes.length];
        const isBass = (ni % 4 === 0);
        try {
            const t0 = audioCtx.currentTime;
            const o = audioCtx.createOscillator(), g = audioCtx.createGain();
            o.type = isBass ? 'sine' : 'triangle';
            o.frequency.setValueAtTime(f, t0);
            g.gain.setValueAtTime(isBass ? 0.055 : 0.038, t0);
            g.gain.exponentialRampToValueAtTime(0.0008, t0 + 0.34);
            o.connect(g); g.connect(masterGain || audioCtx.destination);
            o.start(t0); o.stop(t0 + 0.36);
        } catch (e) {}
        ni++;
    }
    musicTimerId = setInterval(pn, 350); pn();
}
function stopMusic() { if (musicTimerId) { clearInterval(musicTimerId); musicTimerId = null; } }
