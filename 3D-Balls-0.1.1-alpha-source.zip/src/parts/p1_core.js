// ============================================================
// 3D Balls — v0.1.1-alpha (For Windows)
// E-sport UI · render scale · FPS-счётчик · оптимизации · E-Ball
// ============================================================
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { Reflector } from 'three/examples/jsm/objects/Reflector.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

const GAME_VERSION = '0.1.1-alpha';
const IS_ELECTRON = /Electron\//.test(navigator.userAgent);
const EBALL = window.__EBALL__ === true;            // экспериментальная сборка E-Ball
const EBALL_BACKEND = (function () {                // 'vulkan' | 'compat' | null
    try { return new URLSearchParams(location.search || '').get('backend'); } catch (e) { return null; }
})();
const EBALL_GOOSE_MS = (function () {               // время Goose-бенчмарка (мс) | null
    try {
        const g = new URLSearchParams(location.search || '').get('goose');
        return g === null ? null : (parseInt(g, 10) || 0);
    } catch (e) { return null; }
})();
if (IS_ELECTRON) document.body.classList.add('in-electron');
if (EBALL) document.body.classList.add('eball');
document.title = EBALL ? 'E-Ball' : '3D Balls';

// ============ SVG-ИКОНКИ (без эмодзи) ============
const SVG = {
    star: '<path fill="currentColor" stroke="none" d="M12 2.2l2.8 6 6.6.8-4.9 4.5 1.3 6.5L12 16.8l-5.8 3.2 1.3-6.5L2.6 9l6.6-.8z"/>',
    bolt: '<path d="M13 2.5 5.2 14h5.4l-1.1 7.5L17.5 9.5h-5.4l1.6-7z"/>',
    gem: '<path d="M7 4h10l4 5.5L12 21 3 9.5 7 4z"/><path d="M7 4l5 17M17 4l-5 17M4.2 9.5h15.6"/>',
    chain: '<rect x="2.5" y="8" width="8.5" height="8" rx="1.8"/><rect x="13" y="8" width="8.5" height="8" rx="1.8"/><path d="M11 12h2"/>',
    gun: '<path d="M2.5 8h19v4.5h-5.5l-1.8 7h-4.6l1.8-7H8a5.5 5.5 0 0 1-5.5-5.5V8z"/><path d="M15.5 8v2.5"/>',
    welcome: '<path d="M9 4H5v16h4"/><path d="M13 12h8"/><path d="m17 8 4 4-4 4"/>',
    flag: '<path d="M6 21V3"/><path d="M6 4h11l-2.5 4L17 12H6"/>',
    chip: '<rect x="7" y="7" width="10" height="10" rx="1.5"/><rect x="10.5" y="10.5" width="3" height="3"/><path d="M9 7V4M15 7V4M9 20v-3M15 20v-3M7 9H4M7 15H4M20 9h-3M20 15h-3"/>',
    crosshair: '<circle cx="12" cy="12" r="7"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none"/>',
    flame: '<path d="M12 2.5c1.8 3.4 6 5.6 6 10a6 6 0 0 1-12 0c0-2 .9-3.6 2.2-4.8.1 1.9 1 3 2.3 3.3C10 8.5 10.6 5.4 12 2.5z"/>',
    warn: '<path d="M12 3.5 21.5 20h-19L12 3.5z"/><path d="M12 10v4.5"/><circle cx="12" cy="17.4" r=".5" fill="currentColor" stroke="none"/>',
    ban: '<circle cx="12" cy="12" r="8.5"/><path d="M6 6l12 12"/>',
    dcheck: '<path d="m4 12.5 4.5 4.5L15 9"/><path d="m10.5 17 1.5 1.5L21 9.5"/>',
    target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r=".8" fill="currentColor" stroke="none"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5 9-5z"/><path d="m3.5 13 8.5 4.7 8.5-4.7"/>',
    close: '<path d="M5 5l14 14M19 5 5 19"/>',
    trophy: '<path d="M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M7 5H4v2a3 3 0 0 0 3 3M17 5h3v2a3 3 0 0 1-3 3"/><path d="M12 14v4"/><path d="M8 21h8M9.5 18h5"/>'
};
function svgIcon(name, cls) {
    return '<svg class="' + (cls || 'icn') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (SVG[name] || '') + '</svg>';
}

// ============ ЛОКАЛИЗАЦИЯ ============
const I18N = {
    ru: {
        play: 'ИГРАТЬ', playAgain: 'ИГРАТЬ СНОВА',
        upgrades: 'УЛУЧШЕНИЯ', achievements: 'ДОСТИЖЕНИЯ', settings: 'НАСТРОЙКИ', close: 'ЗАКРЫТЬ',
        starsLabel: 'ЗВЁЗДЫ',
        hudTime: 'ВРЕМЯ', hudScore: 'СЧЁТ', hudLives: 'ЖИЗНИ',
        menuScore: 'Звёзд: {n}',
        modeClassic: 'CLASSIC', modeClassicDesc: 'Классический режим',
        modeLevel: 'LEVEL', modeLevelDesc: 'Уровни с заданиями',
        back: 'НАЗАД',
        selectMode: 'ВЫБОР РЕЖИМА', selectLevel: 'ВЫБОР УРОВНЯ',
        level1: 'Уровень 1', level1Desc: 'Лопни все шарики за 10 сек',
        level2: 'Уровень 2', level2Desc: 'Выживи 15 сек в хардкоре',
        level3: 'Уровень 3', level3Desc: 'Лопни 30 молний за 5 сек',
        passed: 'ПРОЙДЕН',
        remaining: 'осталось: {n}',
        success: 'УСПЕХ!', fail: 'ПРОВАЛ',
        reward: 'Вы получили {n} звёзд!', rewardReplay: 'Вы получили {n} звёзд (перепрохождение)!',
        failLightning: 'Осталось {n} молний. Попробуйте снова.',
        failBalls: 'Осталось {n} шариков. Попробуйте снова.',
        continueBtn: 'ПРОДОЛЖИТЬ', retry: 'ПОВТОРИТЬ',
        buy: 'КУПИТЬ', upgAction: 'УЛУЧШИТЬ', max: 'МАКС', insufficient: 'Недостаточно звёзд!',
        openedLabel: 'Открыто:', achToastTitle: 'Достижение получено!',
        bonus: 'БОНУС',
        settingsTitle: 'Настройки',
        duration: 'Длительность игры', sec30: '30 секунд', sec60: '60 секунд', sec90: '90 секунд',
        livesOpt: 'Количество жизней', lives1: '1 жизнь', lives2: '2 жизни', lives3: '3 жизни', lives5: '5 жизней',
        difficulty: 'Сложность', easy: 'Легко', medium: 'Средне', hard: 'Сложно',
        spawnMode: 'Режим спавна', spawnNormal: 'Нормальный', spawnHardcore: 'Хардкор', spawnDebug: 'Отладочный',
        graphics: 'Качество графики', gfxHigh: 'Высокая', gfxLight: 'Лёгкая',
        language: 'Язык интерфейса', langRu: 'Русский', langEn: 'English',
        renderRes: 'Разрешение рендера', rrAuto: 'Авто (динамическое)', rrNative: '100% — родное',
        rr75: '75% + сглаживание', rr50: '50% + сглаживание',
        fpsOpt: 'Счётчик FPS', optOn: 'Вкл', optOff: 'Выкл',
        loading: 'ЗАГРУЗКА', deploySub: 'Развёртывание арены',
        bootStep1: 'Инициализация ядра', bootStep2: 'Загрузка ресурсов', bootStep3: 'Компиляция шейдеров',
        bootStep4: 'Синхронизация прогресса', bootStep5: 'Готово',
        eballBadge: 'ЭКСПЕРИМЕНТ', backendLabel: 'Графический бэкенд', webgpuLabel: 'WebGPU',
        webgpuAvail: 'доступен', webgpuNone: 'недоступен',
        vkHardware: 'Vulkan (аппаратный)', vkSwift: 'Vulkan (SwiftShader — программный)',
        d3dCompat: 'D3D11 (совместимость)', webGlBrowser: 'WebGL браузера',
        vkFallback: 'Vulkan недоступен: включён совместимый режим (D3D11)',
        gooseLabel: 'Goose-модуль', gooseOk: 'OK — {n} мс',
        tutorialBtn: 'TUTORIAL', tutorialTitle: 'Туториал',
        save: 'СОХРАНИТЬ', reset: 'СБРОСИТЬ ПРОГРЕСС',
        resetTitle: 'Сброс прогресса',
        resetText: 'ВНИМАНИЕ! Это действие удалит все ваши звёзды, улучшения, достижения и прогресс уровней. Продолжить?',
        resetYes: 'ДА, СБРОСИТЬ', resetNo: 'ОТМЕНА',
        sec: 'сек',
        semi: 'ПОЛУАВТОМАТ', auto: 'АВТОМАТ',
        ammo: 'МАГАЗИН', reloading: 'ПЕРЕЗАРЯДКА',
        upgLightning: 'Громоотвод', upgGold: 'Золотонос', upgChain: 'Удвоитель молний', upgAuto: 'АВТОМАТИКА',
        tut1h: 'Цель', tut1p: 'Стреляй из пушки по шарикам! Пушка наводится на курсор.',
        tut2h: 'Фиолетовый +1', tut2p: 'Простой шарик. Пропустишь — потеряешь жизнь.',
        tut3h: 'Золотой +5', tut3p: 'Даёт много звёзд.',
        tut4h: 'Красный −2', tut4p: 'Штрафует, но не отнимает жизнь при пропуске.',
        tut5h: 'Молния', tut5p: 'Уничтожает 5 ближайших шариков, может каскадить.',
        tut6h: 'АВТОМАТИКА', tut6p: 'I — пистолет (магазин 15). II — пулемёт (магазин 35, полуавтомат/автомат на B, ~9 выстр/сек). III — миниган (магазин 60, всегда автомат, ~30 выстр/сек, 2.5 сек перезарядка).'
    },
    en: {
        play: 'PLAY', playAgain: 'PLAY AGAIN',
        upgrades: 'UPGRADES', achievements: 'ACHIEVEMENTS', settings: 'SETTINGS', close: 'CLOSE',
        starsLabel: 'STARS',
        hudTime: 'TIME', hudScore: 'SCORE', hudLives: 'LIVES',
        menuScore: 'Stars: {n}',
        modeClassic: 'CLASSIC', modeClassicDesc: 'Classic mode',
        modeLevel: 'LEVEL', modeLevelDesc: 'Objective levels',
        back: 'BACK',
        selectMode: 'SELECT MODE', selectLevel: 'SELECT LEVEL',
        level1: 'Level 1', level1Desc: 'Pop all the balls in 10 sec',
        level2: 'Level 2', level2Desc: 'Survive 15 sec in hardcore',
        level3: 'Level 3', level3Desc: 'Pop 30 lightning balls in 5 sec',
        passed: 'COMPLETED',
        remaining: 'remaining: {n}',
        success: 'SUCCESS!', fail: 'FAILED',
        reward: 'You earned {n} stars!', rewardReplay: 'You earned {n} stars (replay)!',
        failLightning: '{n} lightning balls left. Try again.',
        failBalls: '{n} balls left. Try again.',
        continueBtn: 'CONTINUE', retry: 'RETRY',
        buy: 'BUY', upgAction: 'UPGRADE', max: 'MAX', insufficient: 'Not enough stars!',
        openedLabel: 'Unlocked:', achToastTitle: 'Achievement unlocked!',
        bonus: 'BONUS',
        settingsTitle: 'Settings',
        duration: 'Game duration', sec30: '30 seconds', sec60: '60 seconds', sec90: '90 seconds',
        livesOpt: 'Number of lives', lives1: '1 life', lives2: '2 lives', lives3: '3 lives', lives5: '5 lives',
        difficulty: 'Difficulty', easy: 'Easy', medium: 'Medium', hard: 'Hard',
        spawnMode: 'Spawn mode', spawnNormal: 'Normal', spawnHardcore: 'Hardcore', spawnDebug: 'Debug',
        graphics: 'Graphics quality', gfxHigh: 'High', gfxLight: 'Light',
        language: 'Interface language', langRu: 'Русский', langEn: 'English',
        renderRes: 'Render resolution', rrAuto: 'Auto (dynamic)', rrNative: '100% — native',
        rr75: '75% + smoothing', rr50: '50% + smoothing',
        fpsOpt: 'FPS counter', optOn: 'On', optOff: 'Off',
        loading: 'LOADING', deploySub: 'Deploying arena',
        bootStep1: 'Initializing core', bootStep2: 'Loading assets', bootStep3: 'Compiling shaders',
        bootStep4: 'Syncing progress', bootStep5: 'Ready',
        eballBadge: 'EXPERIMENTAL', backendLabel: 'Render backend', webgpuLabel: 'WebGPU',
        webgpuAvail: 'available', webgpuNone: 'not available',
        vkHardware: 'Vulkan (hardware)', vkSwift: 'Vulkan (SwiftShader — software)',
        d3dCompat: 'D3D11 (compatibility)', webGlBrowser: 'Browser WebGL',
        vkFallback: 'Vulkan unavailable: compatibility mode (D3D11) enabled',
        gooseLabel: 'Goose module', gooseOk: 'OK — {n} ms',
        tutorialBtn: 'TUTORIAL', tutorialTitle: 'Tutorial',
        save: 'SAVE', reset: 'RESET PROGRESS',
        resetTitle: 'Progress reset',
        resetText: 'WARNING! This will delete all your stars, upgrades, achievements and level progress. Continue?',
        resetYes: 'YES, RESET', resetNo: 'CANCEL',
        sec: 'sec',
        semi: 'SEMI-AUTO', auto: 'AUTO',
        ammo: 'MAGAZINE', reloading: 'RELOADING',
        upgLightning: 'Lightning Rod', upgGold: 'Gold Vein', upgChain: 'Chain Doubler', upgAuto: 'AUTOMATIKA',
        tut1h: 'Objective', tut1p: 'Shoot the balls with the cannon! The cannon tracks your cursor.',
        tut2h: 'Purple +1', tut2p: 'A basic ball. Let one slip past — you lose a life.',
        tut3h: 'Golden +5', tut3p: 'Grants a lot of stars.',
        tut4h: 'Red −2', tut4p: 'Penalizes you, but costs no life when it passes.',
        tut5h: 'Lightning', tut5p: 'Destroys the 5 nearest balls and can chain.',
        tut6h: 'AUTOMATIKA', tut6p: 'I — pistol (mag 15). II — machine gun (mag 35, semi/auto on B, ~9 rps). III — minigun (mag 60, always auto, ~30 rps, 2.5 s reload).'
    }
};
let lang = 'ru';
function t(key) {
    const d = I18N[lang] || I18N.ru;
    return (key in d) ? d[key] : (I18N.ru[key] !== undefined ? I18N.ru[key] : key);
}
function tf(key, params) {
    let s = t(key);
    if (params) for (const k in params) s = s.split('{' + k + '}').join(params[k]);
    return s;
}

// ============ СОСТОЯНИЕ ============
let starsBalance = 0;

let upgrades = {
    lightningBoost: { level: 0, active: true },
    goldFever: { level: 0, active: true },
    doubleChain: { level: 0, active: true },
    automatika: { level: 0, active: true }
};

const UPGRADE_DEFS = {
    lightningBoost: {
        maxLevel: 3,
        costs: [0, 700, 420, 560],
        descriptions: {
            ru: ['+10% к спавну зелёных шариков', '+10% к спавну зелёных шариков', '+15% к спавну зелёных шариков', '+25% к спавну зелёных шариков'],
            en: ['+10% green ball spawn rate', '+10% green ball spawn rate', '+15% green ball spawn rate', '+25% green ball spawn rate']
        },
        icon: 'bolt'
    },
    goldFever: {
        maxLevel: 4,
        costs: [0, 1000, 600, 800, 1200],
        descriptions: {
            ru: ['15% шанс +5 звёзд с фиолетового', '15% шанс +5 звёзд с фиолетового', '20% шанс +5 звёзд с фиолетового', '30% шанс +5 звёзд с фиолетового', '40% шанс +5 звёзд с фиолетового'],
            en: ['15% chance of +5 stars from purple', '15% chance of +5 stars from purple', '20% chance of +5 stars from purple', '30% chance of +5 stars from purple', '40% chance of +5 stars from purple']
        },
        icon: 'gem'
    },
    doubleChain: {
        maxLevel: 1,
        costs: [0, 1200],
        descriptions: {
            ru: ['Молния уничтожает до 10 шариков', 'Молния уничтожает до 10 шариков'],
            en: ['Lightning destroys up to 10 balls', 'Lightning destroys up to 10 balls']
        },
        icon: 'chain'
    },
    automatika: {
        maxLevel: 3,
        costs: [0, 1200, 720, 960],
        descriptions: {
            ru: ['Пистолет, магазин 15, перезарядка 1.5 сек', 'Пистолет, магазин 15, перезарядка 1.5 сек', 'Пулемёт, магазин 35, полуавтомат/автомат (B)', 'Миниган, магазин 60, всегда автомат, 2.5 сек перезарядка'],
            en: ['Pistol, 15-round mag, 1.5 s reload', 'Pistol, 15-round mag, 1.5 s reload', 'Machine gun, 35-round mag, semi/auto (B)', 'Minigun, 60-round mag, always auto, 2.5 s reload']
        },
        icon: 'gun'
    }
};

let machinegunAutoMode = false;
let level1Completed = false, level2Completed = false, level3Completed = false;
let settings = { duration: 60, lives: 3, difficulty: 'medium', spawnMode: 'normal', graphicsQuality: 'beautiful', lang: 'ru', renderScale: 'auto', fpsCounter: 1 };

const ACHIEVEMENTS = [
    { id: 'welcome', icon: 'welcome', name: { ru: 'Welcome!', en: 'Welcome!' }, desc: { ru: 'Зайдите в игру в первый раз', en: 'Launch the game for the first time' } },
    { id: 'first_win', icon: 'flag', name: { ru: 'Первая победа', en: 'First Victory' }, desc: { ru: 'Закончите свою первую партию', en: 'Finish your first game session' } },
    { id: 'automation', icon: 'chip', name: { ru: 'Автоматизация', en: 'Automation' }, desc: { ru: 'Изучите улучшение "Автоматика I"', en: 'Research the "Automatika I" upgrade' } },
    { id: 'technique', icon: 'crosshair', name: { ru: 'Вот это техника!', en: "Now That's Technique!" }, desc: { ru: 'Испытайте в бою автомат из "Автоматики II"', en: 'Use the Automatika II machine gun in combat' } },
    { id: 'burn_me', icon: 'flame', name: { ru: 'Сожги меня дотла!!!', en: 'Burn Me To The Ground!!!' }, desc: { ru: 'Непрерывная очередь из 60 патронов минигана', en: 'Fire a continuous 60-round minigun burst' } },
    { id: 'comp_almost_died', icon: 'warn', name: { ru: 'Комп чуть не умер!', en: 'PC Almost Died!' }, desc: { ru: 'Победите в 3 уровне, лопнув все молнии', en: 'Beat level 3 by popping all lightning balls' } },
    { id: 'impossible', icon: 'ban', name: { ru: 'Это невозможно!', en: 'This Is Impossible!' }, desc: { ru: 'Проиграйте во 2 уровне с дефолт-пушкой', en: 'Lose level 2 with the default cannon' } },
    { id: 'better', icon: 'dcheck', name: { ru: 'Ну так лучше, да', en: 'Much Better Now' }, desc: { ru: 'Победите во 2 уровне с Автоматикой II/III', en: 'Beat level 2 with Automatika II/III' } }
];
let achievements = {};
let firstRunDetected = false;

try {
    const s = localStorage.getItem('neonStars');
    if (s !== null) starsBalance = parseInt(s, 10) || 0;

    const u = localStorage.getItem('neonUpgrades');
    if (u) {
        const p = JSON.parse(u);
        if (typeof p.lightningBoost === 'boolean' || (p.lightningBoost && typeof p.lightningBoost === 'object' && 'purchased' in p.lightningBoost)) {
            const lb = p.lightningBoost, gf = p.goldFever, dc = p.doubleChain;
            const lbActive = typeof lb === 'object' ? lb.active : !!lb;
            const gfActive = typeof gf === 'object' ? gf.active : !!gf;
            const dcActive = typeof dc === 'object' ? dc.active : !!dc;
            const lbPurch = typeof lb === 'object' ? lb.purchased : !!lb;
            const gfPurch = typeof gf === 'object' ? gf.purchased : !!gf;
            const dcPurch = typeof dc === 'object' ? dc.purchased : !!dc;
            let autoLvl = 0;
            if (p.pistol && (p.pistol.purchased || p.pistol === true)) autoLvl = Math.max(autoLvl, 1);
            if (p.machinegun && (p.machinegun.purchased || p.machinegun === true)) autoLvl = Math.max(autoLvl, 2);
            upgrades = {
                lightningBoost: { level: lbPurch ? 1 : 0, active: lbActive },
                goldFever: { level: gfPurch ? 1 : 0, active: gfActive },
                doubleChain: { level: dcPurch ? 1 : 0, active: dcActive },
                automatika: { level: autoLvl, active: true }
            };
        } else if (p.lightningBoost && typeof p.lightningBoost === 'object' && 'level' in p.lightningBoost) {
            upgrades = Object.assign(upgrades, p);
        }
    }

    if (localStorage.getItem('level1_completed') === 'true') level1Completed = true;
    if (localStorage.getItem('level2_completed') === 'true') level2Completed = true;
    if (localStorage.getItem('level3_completed') === 'true') level3Completed = true;

    const st = localStorage.getItem('neonBallSettings');
    if (st) {
        settings = Object.assign(settings, JSON.parse(st));
        if (settings.lang !== 'ru' && settings.lang !== 'en') settings.lang = 'ru';
    }
    lang = settings.lang || 'ru';

    const savedAch = localStorage.getItem('neonAchievements');
    if (savedAch === null) {
        firstRunDetected = true;
        achievements = {};
    } else {
        try { achievements = JSON.parse(savedAch) || {}; } catch (e) { achievements = {}; }
    }
} catch (e) { /* приватный режим и т.п. */ }

function saveState() {
    try {
        localStorage.setItem('neonStars', starsBalance);
        localStorage.setItem('neonUpgrades', JSON.stringify(upgrades));
        localStorage.setItem('level1_completed', level1Completed ? 'true' : 'false');
        localStorage.setItem('level2_completed', level2Completed ? 'true' : 'false');
        localStorage.setItem('level3_completed', level3Completed ? 'true' : 'false');
        settings.lang = lang;
        localStorage.setItem('neonBallSettings', JSON.stringify(settings));
        localStorage.setItem('neonAchievements', JSON.stringify(achievements));
    } catch (e) {}
}
