// ============ ОБНОВЛЕНИЕ СНАРЯДОВ ============
const _scaleTarget = new THREE.Vector3();
function updateProjectiles(dt) {
    for (let i = projectiles.length - 1; i >= 0; i--) {
        const p = projectiles[i];
        if (!p.visible) { projectiles.splice(i, 1); continue; }
        const u = p.userData;
        u.age += dt;
        if (u.age >= u.life) {
            releaseEffect(p); projectiles.splice(i, 1); continue;
        }
        const vel = u.velocity;
        p.position.x += vel.x * dt;
        p.position.y += vel.y * dt;
        p.position.z += vel.z * dt;

        // Трассер-хвост (из пула — без аллокаций)
        if (particles.length < 420) {
            u.trailAcc += vel.length() * dt;
            if (u.trailAcc > 0.32) {
                u.trailAcc = 0;
                spawnParticle(p.position.x, p.position.y, p.position.z, 0x5da8ff, 0.07, 0.22, 0, 0, 0, 0, 'trail');
            }
        }

        if (p.position.z > 8 || p.position.z < -8 ||
            p.position.x > 8 || p.position.x < -8 ||
            p.position.y < -1 || p.position.y > 8) {
            releaseEffect(p); projectiles.splice(i, 1); continue;
        }

        let hit = false;
        for (let b = 0; b < balls.length && !hit; b++) {
            const ball = balls[b];
            if (!ball.parent || ball.userData.targetScale === 0) continue;
            if (p.position.distanceTo(ball.position) < 0.5) { damageBall(ball); hit = true; }
        }
        if (!hit && typeof levelBalls !== 'undefined') {
            for (let b = 0; b < levelBalls.length && !hit; b++) {
                const ball = levelBalls[b];
                if (!ball.parent || ball.userData.targetScale === 0) continue;
                if (p.position.distanceTo(ball.position) < 0.5) { damageBall(ball); hit = true; }
            }
        }
        if (hit) {
            spawnSpriteFx(p.position.x, p.position.y, p.position.z, 0x7fc4ff, 0.9, 0.6, 0.25, 'pflash');
            releaseEffect(p); projectiles.splice(i, 1);
        }
    }
}

function damageBall(sphere) {
    if (!sphere || !sphere.parent) return;
    if (levelActive) {
        const type = sphere.userData.type;
        if (type === 'lightning') {
            chainLightning(sphere);
            const rem = levelBalls.filter(b => b.parent).length;
            levelExtraInfo.textContent = tf('remaining', { n: rem });
            if (rem === 0) levelSuccess(currentLevelNum);
            return;
        }
        if (type === 'golden') { sfxGolden(); createExplosion(sphere.position, 0xffd966, 40, [0.06, 0.3], 1.2, ['#ffd966', '#ffb347', '#ff8c00']); }
        else if (type === 'bomb') { sfxBomb(); createExplosion(sphere.position, 0xff5555, 45, [0.07, 0.3], 1.4, ['#ff5555', '#ff0000', '#cc0000', '#ffaa00'], 0.16); }
        else { sfxPop(); createExplosion(sphere.position, 0xbb77ff, 30, [0.04, 0.2], 1.0, ['#bb77ff', '#9b59b6', '#8e44ad']); }
        sphere.userData.targetScale = 0;
        setTimeout(() => {
            if (sphere.parent) gameGroup.remove(sphere);
            disposeBallMesh(sphere);
        }, 200);
        const i = levelBalls.indexOf(sphere);
        if (i !== -1) levelBalls.splice(i, 1);
        const rem = levelBalls.filter(b => b.parent).length;
        levelExtraInfo.textContent = tf('remaining', { n: rem });
        if (rem === 0) levelSuccess(currentLevelNum);
    } else {
        processHit(sphere);
    }
}

// ============ ГРАФИКА ============
function applyGraphicsQuality() {
    const isLight = settings.graphicsQuality === 'light';
    reflectorFloor.visible = !isLight;
    simpleFloor.visible = isLight;
    bloomPass.enabled = !isLight;
    starPoints.material.size = isLight ? 0.08 : 0.11;

    // В лёгком режиме тени отключаются полностью — заметный прирост FPS
    const shadowsOn = !isLight;
    if (renderer.shadowMap.enabled !== shadowsOn) {
        renderer.shadowMap.enabled = shadowsOn;
        dirLight.castShadow = shadowsOn;
        scene.traverse(o => { if (o.material) o.material.needsUpdate = true; });
    }

    if (isLight) {
        renderer.toneMappingExposure = 1.55;
        dirLight.intensity = 1.65;
        fillLight.intensity = 1.05;
        ambientLight.intensity = 0.6;
        accentLight1.intensity = 0.85;
        accentLight2.intensity = 0.85;
    } else {
        renderer.toneMappingExposure = 1.2;
        dirLight.intensity = 1.25;
        fillLight.intensity = 0.6;
        ambientLight.intensity = 0.0;
        accentLight1.intensity = 0.55;
        accentLight2.intensity = 0.5;
    }
}

function getBallMaterial(color, emissive) {
    if (settings.graphicsQuality === 'light') {
        return new THREE.MeshStandardMaterial({
            color, emissive,
            roughness: 0.25, metalness: 0.1,
            emissiveIntensity: 1.4
        });
    }
    return new THREE.MeshPhysicalMaterial({
        color, emissive, roughness: 0.22, metalness: 0.45,
        clearcoat: 0.65, clearcoatRoughness: 0.25,
        envMap: envTexture, envMapIntensity: 1.15, emissiveIntensity: 0.9
    });
}

// ============ ИГРА ============
const raycaster = new THREE.Raycaster(), mouse = new THREE.Vector2();
function isOverlapping(newPos, radius, existingBalls, margin = 0.3) {
    const r = radius || 0.4;
    for (let b of existingBalls) {
        if (!b.parent) continue;
        const dx = b.position.x - newPos.x, dz = b.position.z - newPos.z;
        const dist = Math.sqrt(dx * dx + dz * dz);
        const otherR = b.geometry.parameters ? b.geometry.parameters.radius : 0.4;
        if (dist < otherR + r + margin) return true;
    }
    return false;
}

// Кольцо появления шарика (из пула)
function spawnRing(x, z, colorHex) {
    const ring = spawnRingFx(RING_GEO_BIG, x, -0.48, z, colorHex, 0.5);
    ring.rotation.x = -Math.PI / 2;
}

// Общая геометрия шарика — без аллокации сферы на каждый спавн
const BALL_GEO = new THREE.SphereGeometry(0.4, 32, 32);
function createClassicBall(type, speedMultiplier = 1.0) {
    const cfg = {
        normal: { color: 0xbb77ff, emissive: 0x440066 },
        golden: { color: 0xffd966, emissive: 0x553300 },
        bomb: { color: 0xff5555, emissive: 0x550000 },
        lightning: { color: 0x44ff44, emissive: 0x004400 }
    }[type];
    const sphere = new THREE.Mesh(BALL_GEO, getBallMaterial(cfg.color, cfg.emissive));
    sphere.castShadow = true; sphere.receiveShadow = true;
    const halfRange = 4.2; let x, z, att = 0;
    do { x = (Math.random() * 2 - 1) * halfRange; z = -4.5 + Math.random() * 0.5; att++; }
    while (isOverlapping({ x, z }, 0.4, balls) && att < 30);
    sphere.position.set(x, BALL_Y_FLOOR, z);
    sphere.scale.set(0, 0, 0);
    sphere.userData = {
        type, targetScale: 1, activated: false, speed: (0.8 + Math.random() * 0.4) * speedMultiplier,
        seed: Math.random() * Math.PI * 2, spawnDrop: 0.8, baseEI: 0.9
    };
    // Ореол для молний и золотых
    if (type === 'lightning' || type === 'golden') {
        const haloMat = new THREE.SpriteMaterial({
            map: glowTexture, color: type === 'lightning' ? 0x66ff88 : 0xffe9a8,
            transparent: true, opacity: 0.28,
            blending: THREE.AdditiveBlending, depthWrite: false
        });
        const halo = new THREE.Sprite(haloMat);
        halo.scale.set(1.1, 1.1, 1);
        sphere.add(halo);
        sphere.userData.halo = halo;
    }
    gameGroup.add(sphere); balls.push(sphere);
    spawnRing(x, z, cfg.color);
    return sphere;
}
function disposeBallMesh(sphere) {
    if (sphere.material) sphere.material.dispose();
    if (sphere.userData && sphere.userData.halo && sphere.userData.halo.material) sphere.userData.halo.material.dispose();
}
function removeBall(sphere, hit = false) {
    const i = balls.indexOf(sphere);
    if (i === -1) return;
    balls.splice(i, 1);
    sphere.userData.targetScale = 0;
    setTimeout(() => {
        if (sphere.parent) gameGroup.remove(sphere);
        disposeBallMesh(sphere);
    }, hit ? 200 : 300);
}
function updateClassicMovement(dt, time) {
    if (!gameActive) return;
    for (let i = balls.length - 1; i >= 0; i--) {
        const s = balls[i];
        if (!s.parent) continue;
        const prog = (s.position.z - (-4.5)) / 9;
        s.position.z += s.userData.speed * (1 + prog * 2.5) * dt;
        const t = s.userData.targetScale;
        _scaleTarget.set(t, t, t);
        s.scale.lerp(_scaleTarget, 0.15);
        // Появление с "падением" + лёгкое парение
        if (s.userData.spawnDrop > 0) {
            s.userData.spawnDrop = Math.max(0, s.userData.spawnDrop - dt * 2.6);
            s.position.y = BALL_Y_FLOOR + s.userData.spawnDrop * s.userData.spawnDrop * 0.9;
        } else {
            s.position.y = BALL_Y_FLOOR + Math.sin(time * 2.4 + s.userData.seed) * 0.035;
        }
        if (s.position.z >= 4.5) {
            if (s.userData.type === 'bomb') removeBall(s, false);
            else {
                removeBall(s, false);
                lives--; updateHUD();
                if (lives <= 0) { endClassicGame(); return; }
            }
        }
    }
}
function spawnClassicBall(speedMult) {
    if (!gameActive) return;
    const mode = settings.spawnMode || 'normal';
    const elapsed = settings.duration - timeLeft;
    let type;
    if (mode === 'debug') {
        if (elapsed < 10) type = 'golden';
        else type = Math.random() < 0.5 ? 'lightning' : 'bomb';
    } else {
        let pL = (mode === 'hardcore') ? 0.15 : 0.08;
        let pB = (mode === 'hardcore') ? 0.27 : 0.18;
        let pG = (mode === 'hardcore') ? 0.45 : 0.33;
        const lbVal = getLightningBoostValue();
        if (lbVal > 0) {
            pL += lbVal;
            if (pL > 0.5) pL = 0.5;
            const rest = 1 - pL;
            const scale = rest / (pB + pG);
            pB *= scale; pG *= scale;
        }
        const r = Math.random();
        if (r < pL) type = 'lightning';
        else if (r < pL + pB) type = 'bomb';
        else if (r < pL + pB + pG) type = 'golden';
        else type = 'normal';
    }
    createClassicBall(type, speedMult);
}
function scheduleClassicSpawn(speedMult) {
    if (!gameActive) return;
    const diff = difficultySettings[settings.difficulty];
    const elapsed = settings.duration - timeLeft;
    const prog = Math.min(elapsed / settings.duration, 1);
    let delay = diff.spawnInterval - prog * (diff.spawnInterval - diff.minSpawnInterval);
    if (settings.spawnMode === 'hardcore') delay *= 0.35;
    spawnTimerId = setTimeout(() => {
        const mode = settings.spawnMode || 'normal';
        const maxBalls = (mode === 'hardcore') ? MAX_BALLS_HARDCORE : MAX_BALLS_NORMAL;
        if (gameActive && balls.length < maxBalls) spawnClassicBall(speedMult);
        scheduleClassicSpawn(speedMult);
    }, delay * 1000);
}
function processHit(sphere) {
    const type = sphere.userData.type;
    let points = 0;
    if (type === 'golden') points = 5;
    else if (type === 'bomb') points = -2;
    else if (type === 'lightning') { chainLightning(sphere); return; }
    else {
        points = 1;
        const gfChance = getGoldFeverChance();
        if (gfChance > 0 && Math.random() < gfChance) points = 5;
    }
    currentStars = Math.max(0, currentStars + points);
    updateHUD();
    if (type === 'golden' || (type === 'normal' && points === 5)) { sfxGolden(); createExplosion(sphere.position, 0xffd966, 40, [0.06, 0.3], 1.2, ['#ffd966', '#ffb347', '#ff8c00']); }
    else if (type === 'bomb') { sfxBomb(); createExplosion(sphere.position, 0xff5555, 45, [0.07, 0.3], 1.4, ['#ff5555', '#ff0000', '#cc0000', '#ffaa00'], 0.16); }
    else { sfxPop(); createExplosion(sphere.position, 0xbb77ff, 30, [0.04, 0.2], 1.0, ['#bb77ff', '#9b59b6', '#8e44ad']); }
    removeBall(sphere, true);
}
const _paletteCache = {};
const DEFAULT_POP_PALETTE = ['#bb77ff', '#9b59b6', '#8e44ad', '#a98fd4', '#7d4bb5'];
function _paletteColors(palette) {
    const key = palette ? palette.join('|') : 'default';
    if (!_paletteCache[key]) {
        _paletteCache[key] = (palette || DEFAULT_POP_PALETTE).map(c => new THREE.Color(c));
    }
    return _paletteCache[key];
}
function createExplosion(position, baseColor, count = 35, sizeRange = [0.05, 0.25], duration = 1.0, palette = null, shake = 0) {
    const colors = _paletteColors(palette);
    const n = count + Math.floor(Math.random() * 15);
    for (let i = 0; i < n; i++) {
        const size = sizeRange[0] + Math.random() * (sizeRange[1] - sizeRange[0]);
        const color = colors[Math.floor(Math.random() * colors.length)];
        const speed = 0.05 + Math.random() * 0.18;
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI - Math.PI / 2;
        spawnParticle(
            position.x, position.y, position.z, color, size,
            duration * (0.6 + Math.random() * 0.4),
            Math.cos(theta) * Math.cos(phi) * speed,
            Math.sin(phi) * speed + 0.025,
            Math.sin(theta) * Math.cos(phi) * speed,
            (Math.random() - 0.5) * 0.1, 'bit'
        );
    }
    spawnFlashFx(position.x, position.y, position.z, baseColor);
    const ring = spawnRingFx(RING_GEO_SMALL, position.x, position.y, position.z, baseColor, 0.6);
    ring.lookAt(camera.position);
    if (shake > 0) shakeCamera(shake);
}

// Тряска камеры
let camShake = 0;
function shakeCamera(amount) { camShake = Math.min(0.4, camShake + amount); }

function createZigzagLine3D(start, end, segments = 4) {
    const pts = [start.clone()];
    const dir = end.clone().sub(start);
    const len = dir.length();
    if (len < 0.01) return pts;
    const perp = new THREE.Vector3(-dir.z, 0, dir.x).normalize();
    for (let i = 1; i < segments; i++) {
        const t = i / segments;
        const pos = start.clone().lerp(end, t);
        pos.add(perp.clone().multiplyScalar((Math.random() - 0.5) * 0.3 * len));
        pos.y += (Math.random() - 0.5) * 0.3;
        pts.push(pos);
    }
    pts.push(end.clone());
    return pts;
}
function chainLightning(sourceSphere, delay = 0) {
    if (!sourceSphere.parent) return;
    sourceSphere.userData.activated = true;
    const sourcePos = sourceSphere.position.clone();
    let targetArray = balls, isLevel = false;
    if (sourceSphere.userData.isLevelBall) {
        targetArray = (typeof levelBalls !== 'undefined') ? levelBalls : balls;
        isLevel = true;
    }
    const cands = targetArray.filter(b => b !== sourceSphere && b.parent && !b.userData.activated);
    cands.sort((a, b) => a.position.distanceTo(sourcePos) - b.position.distanceTo(sourcePos));
    const maxT = isUpgradeActive('doubleChain') ? 10 : 5;
    const targets = cands.slice(0, maxT);
    targets.forEach(target => {
        const pts = createZigzagLine3D(sourcePos, target.position, 4 + Math.floor(Math.random() * 3));
        spawnBoltLine(pts);
        for (let i = 0; i < 20; i++) {
            const tt = Math.random();
            const px = sourcePos.x + (target.position.x - sourcePos.x) * tt + (Math.random() - 0.5) * 0.5;
            const py = sourcePos.y + (target.position.y - sourcePos.y) * tt + (Math.random() - 0.5) * 0.3;
            const pz = sourcePos.z + (target.position.z - sourcePos.z) * tt + (Math.random() - 0.5) * 0.5;
            spawnParticle(px, py, pz, 0x88ff88, 0.04, 0.3 + Math.random() * 0.3,
                (Math.random() - 0.5) * 0.1, (Math.random() - 0.5) * 0.1 + 0.02, (Math.random() - 0.5) * 0.1, 0, 'bit');
        }
    });
    sfxLightning();
    createExplosion(sourcePos, 0x44ff44, 25, [0.03, 0.15], 0.8);
    const newL = [];
    targets.forEach(target => {
        if (target.userData.type === 'lightning' && !target.userData.activated) {
            target.userData.activated = true;
            newL.push(target);
        } else if (isLevel) {
            const tT = target.userData.type;
            if (tT === 'golden') { sfxGolden(); createExplosion(target.position, 0xffd966, 40, [0.06, 0.3], 1.2, ['#ffd966', '#ffb347', '#ff8c00']); }
            else if (tT === 'bomb') { sfxBomb(); createExplosion(target.position, 0xff5555, 45, [0.07, 0.3], 1.4, ['#ff5555', '#ff0000', '#cc0000', '#ffaa00'], 0.16); }
            else { sfxPop(); createExplosion(target.position, 0xbb77ff, 30, [0.04, 0.2], 1.0, ['#bb77ff', '#9b59b6', '#8e44ad']); }
            target.userData.targetScale = 0;
            setTimeout(() => {
                if (target.parent) gameGroup.remove(target);
                disposeBallMesh(target);
            }, 200);
            const i = targetArray.indexOf(target);
            if (i !== -1) targetArray.splice(i, 1);
            if (typeof levelExtraInfo !== 'undefined') levelExtraInfo.textContent = tf('remaining', { n: targetArray.filter(b => b.parent).length });
        } else processHit(target);
    });
    if (isLevel) {
        const i = levelBalls.indexOf(sourceSphere);
        if (i !== -1) levelBalls.splice(i, 1);
        sourceSphere.userData.targetScale = 0;
        setTimeout(() => {
            if (sourceSphere.parent) gameGroup.remove(sourceSphere);
            disposeBallMesh(sourceSphere);
        }, 200);
        if (typeof levelExtraInfo !== 'undefined') levelExtraInfo.textContent = tf('remaining', { n: levelBalls.filter(b => b.parent).length });
    } else removeBall(sourceSphere, true);
    if (newL.length > 0) setTimeout(() => newL.forEach(b => { if (b.parent) chainLightning(b, 0); }), 200 + delay);
}
