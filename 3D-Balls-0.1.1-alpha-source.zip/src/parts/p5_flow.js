// ============ ОЧИСТКА СЦЕНЫ ============
function clearBalls() {
    while (gameGroup.children.length > 0) {
        const c = gameGroup.children[0];
        gameGroup.remove(c);
        if (c.material) c.material.dispose();
        if (c.userData && c.userData.halo && c.userData.halo.material) c.userData.halo.material.dispose();
    }
}
function clearEffects() {
    for (let i = projectiles.length - 1; i >= 0; i--) releaseEffect(projectiles[i]);
    projectiles.length = 0;
    for (let i = particles.length - 1; i >= 0; i--) releaseEffect(particles[i]);
    particles.length = 0;
}

// ============ СТАРТ/КОНЕЦ ИГРЫ ============
function startClassicGame() {
    initAudio();
    mainMenu.classList.remove('active');
    modeSelect.classList.remove('active');
    levelsMenu.classList.remove('active');
    hud.classList.add('active');
    decorGroup.visible = false;
    clearBalls();
    clearEffects();
    isReloading = false;
    continuousShots = 0;
    initMagazine();
    balls = []; particles = [];
    currentStars = 0; timeLeft = settings.duration; lives = settings.lives;
    gameActive = true;
    setGunVisible(true);
    let sm = 1.0;
    if (settings.difficulty === 'easy') sm = 0.7;
    else if (settings.difficulty === 'hard') sm = 1.3;
    updateHUD(); startMusic();
    gameTimerId = setInterval(() => {
        timeLeft--; updateHUD();
        if (timeLeft <= 0) endClassicGame();
    }, 1000);
    scheduleClassicSpawn(sm);
    if (!animFrameId) animateGame();
}

function endClassicGame() {
    if (!gameActive) return;
    gameActive = false;
    clearTimeout(spawnTimerId); clearInterval(gameTimerId);
    stopMusic(); sfxGameOver();
    hud.classList.remove('active');
    starsBalance += currentStars;
    saveState(); updateStarsDisplay();
    menuScore.textContent = tf('menuScore', { n: currentStars });
    menuScore.classList.remove('hidden');
    mainMenu.classList.add('active');
    decorGroup.visible = true;
    setGunVisible(false);
    clearBalls();
    clearEffects();
    playBtn.textContent = t('playAgain');
    updateUpgradesUI();
    unlockAchievement('first_win');
}

const _hudCache = { lives: -1, score: -1, time: -1 };
function updateHUD() {
    if (timeLeft !== _hudCache.time) {
        _hudCache.time = timeLeft;
        hudTime.textContent = timeLeft;
        hudTime.classList.toggle('low', timeLeft <= 10);
    }
    if (currentStars !== _hudCache.score) {
        _hudCache.score = currentStars;
        hudScore.textContent = currentStars;
    }
    if (lives !== _hudCache.lives) {
        _hudCache.lives = lives;
        const pips = Math.max(0, Math.min(lives, 10));
        let html = '';
        for (let i = 0; i < pips; i++) html += '<span class="pip on"></span>';
        hudLives.innerHTML = html || '<span class="pip"></span>';
    }
}

function updateParticles(dt) {
    for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        if (!p.visible) { particles.splice(i, 1); continue; }
        const u = p.userData;
        u.age += dt;
        if (u.age >= u.life) {
            releaseEffect(p); particles.splice(i, 1);
            continue;
        }
        const v = u.velocity;
        if (v) {
            v.y -= 0.015;
            p.position.x += v.x;
            p.position.y += v.y;
            p.position.z += v.z;
        }
        const lr = u.age / u.life;
        if (p.material) p.material.opacity = Math.max(0, 1 - lr * 1.2);
        const base = u.baseScale || 1;
        let g = 1 + lr * 0.8;
        if (u.type === 'flash') g = 1 + lr * 15;
        else if (u.type === 'ring') g = 1 + lr * 5;
        else if (u.type === 'pflash') g = 1 + lr * 2;
        else if (u.type === 'muzzle') g = 1 + lr * 2.6;
        else if (u.type === 'trail') g = 1 + lr * 0.9;
        const s = base * g;
        if (u.isSprite) p.scale.set(s, s, 1);
        else p.scale.set(s, s, s);
        if (u.rotSpeed) p.rotation.z += u.rotSpeed;
        if (u.type === 'flash') p.material.opacity = Math.max(0, 1 - lr * 2);
        else if (u.type === 'ring') p.material.opacity = Math.max(0, 1 - lr * 2);
        else if (u.type === 'pflash') p.material.opacity = Math.max(0, 1 - lr * 1.5);
        else if (u.type === 'muzzle') p.material.opacity = Math.max(0, 1 - lr * 1.6);
    }
}

// FX шариков: вращение, пульсация бомб, ореолы
function updateBallFX(dt, time) {
    function doFx(s) {
        const u = s.userData;
        if (!u || !s.parent) return;
        if (u.type === 'golden') s.rotation.y += dt * 1.3;
        else if (u.type !== 'lightning') s.rotation.y += dt * 0.45;
        if (u.spawnDrop > 0) {
            u.spawnDrop = Math.max(0, u.spawnDrop - dt * 2.6);
            s.position.y = BALL_Y_FLOOR + u.spawnDrop * u.spawnDrop * 0.9;
        } else {
            s.position.y = BALL_Y_FLOOR + Math.sin(time * 2.4 + (u.seed || 0)) * 0.035;
        }
        if (u.type === 'bomb' && s.material && s.material.emissiveIntensity !== undefined) {
            s.material.emissiveIntensity = u.baseEI + 0.7 + Math.sin(time * 8 + (u.seed || 0)) * 0.7;
        }
        if (u.halo) {
            u.halo.material.opacity = (u.type === 'lightning')
                ? 0.2 + Math.sin(time * 10 + (u.seed || 0)) * 0.12
                : 0.14 + Math.sin(time * 3 + (u.seed || 0)) * 0.08;
        }
    }
    for (let i = 0; i < balls.length; i++) doFx(balls[i]);
    if (typeof levelBalls !== 'undefined') for (let i = 0; i < levelBalls.length; i++) doFx(levelBalls[i]);
}

// ============ FPS + ДИНАМИЧЕСКОЕ РАЗРЕШЕНИЕ ============
let statFrames = 0, statTimeMs = 0, statWindowStart = performance.now();

function refreshFpsHud() {
    if (fpsHud) fpsHud.classList.toggle('on', !!settings.fpsCounter);
}
function updateFpsStats(now) {
    const elapsed = now - statWindowStart;
    if (elapsed < 500 || statFrames === 0) return;
    const avgMs = statTimeMs / statFrames;
    const fps = 1000 / avgMs;
    if (settings.fpsCounter && fpsHud) {
        fpsHud.classList.add('on');
        fpsValEl.textContent = String(Math.round(fps));
        fpsMsEl.textContent = avgMs.toFixed(1) + ' ms';
        const sc = currentRenderScale();
        const showScale = sc < 0.999 || settings.renderScale === 'auto';
        fpsScaleEl.style.display = showScale ? '' : 'none';
        if (showScale) fpsScaleEl.textContent = Math.round(sc * 100) + '%';
        fpsHud.classList.toggle('good', fps >= 55);
        fpsHud.classList.toggle('mid', fps >= 30 && fps < 55);
        fpsHud.classList.toggle('bad', fps < 30);
    } else if (fpsHud) {
        fpsHud.classList.remove('on');
    }
    if (settings.renderScale === 'auto') {
        if (avgMs > 19 && dynamicScale > 0.5) {
            dynamicScale = Math.max(0.5, dynamicScale - 0.125);
            applyRenderScale();
            drGoodStreak = 0;
        } else if (avgMs < 13.5) {
            drGoodStreak++;
            if (drGoodStreak >= 2 && dynamicScale < renderScaleCeiling) {
                dynamicScale = Math.min(renderScaleCeiling, dynamicScale + 0.125);
                applyRenderScale();
                drGoodStreak = 0;
            }
        } else {
            drGoodStreak = 0;
        }
    }
    statFrames = 0; statTimeMs = 0;
    statWindowStart = now;
}

// ============ ГЛАВНЫЙ ЦИКЛ ============
let lastLogicTs = performance.now();
let lastIngameState = null;

function animateGame(ts) {
    animFrameId = requestAnimationFrame(animateGame);
    const now = ts !== undefined ? ts : performance.now();
    const rawDtMs = Math.max(0, now - lastLogicTs);
    const dt = Math.min(rawDtMs / 1000, 0.05);
    lastLogicTs = now;
    const time = now / 1000;
    statFrames++; statTimeMs += rawDtMs;
    updateFpsStats(now);

    if (decorGroup.visible) {
        starPoints.rotation.y += 0.0002;
        decorRings.forEach(r => { r.mesh.rotation.z += r.speed * dt; });
        decorBalls.forEach(item => {
            item.angle += item.speed;
            item.mesh.position.x = Math.cos(item.angle) * item.radius;
            item.mesh.position.z = Math.sin(item.angle) * item.radius;
            item.mesh.position.y = item.centerY + Math.sin(item.angle * 2) * item.ampY;
            item.mesh.rotation.y += dt * 0.3;
        });
        // Медленный дрейф камеры в меню
        if (!gameActive && !levelActive) {
            camera.position.x = Math.sin(time * 0.08) * 0.7;
            camera.position.y = CAM_BASE.y + Math.sin(time * 0.05) * 0.25;
            camera.position.z = CAM_BASE.z;
            camera.lookAt(0, 0.4, 0);
        }
    } else {
        // Тряска камеры
        if (camShake > 0.0005) {
            camera.position.set(
                CAM_BASE.x + (Math.random() - 0.5) * camShake,
                CAM_BASE.y + (Math.random() - 0.5) * camShake,
                CAM_BASE.z + (Math.random() - 0.5) * camShake * 0.5
            );
            camShake *= Math.exp(-dt * 7);
            camera.lookAt(0, 0, 0);
        } else if (camShake !== 0) {
            camShake = 0;
            camera.position.copy(CAM_BASE);
            camera.lookAt(0, 0, 0);
        }
    }

    if (gameActive) updateClassicMovement(dt, time);
    const inGameNow = hud.classList.contains('active') || levelHud.classList.contains('active');
    if (inGameNow !== lastIngameState) {
        lastIngameState = inGameNow;
        document.body.classList.toggle('ingame', inGameNow);
    }
    updateBallFX(dt, time);
    updateParticles(dt);
    for (let i = 0; i < gameGroup.children.length; i++) {
        const s = gameGroup.children[i];
        const tt = s.userData ? s.userData.targetScale : undefined;
        if (tt !== undefined) {
            _scaleTarget.set(tt, tt, tt);
            s.scale.lerp(_scaleTarget, 0.15);
        }
    }

    // Пушка: наведение, отдача, перезарядка — только когда она на арене
    if (gunActive) {
        gunGroup.position.y = GUN_POS.y + Math.sin(time * 1.6) * 0.006;
        updateGunAim();
        updateGunRotation(dt);
        muzzleFlashLight.intensity *= Math.pow(0.0001, dt);
        if (muzzleFlashLight.intensity < 0.03) muzzleFlashLight.intensity = 0;
    }
    updateReload();
    updateReloadBar();
    updateProjectiles(dt);
    if (gunActive && firingHeld) {
        if (isAlwaysAuto() || (canUseAutoMode() && machinegunAutoMode)) tryFire();
    }

    composer.render();
}

// ============ ЭКРАН РАЗВЁРТЫВАНИЯ (загрузка режима/уровня) ============
let deployBusy = false;
const DEPLOY_TIPS = ['tut2p', 'tut3p', 'tut4p', 'tut5p'];
function deployThen(titleText, startFn) {
    if (deployBusy) { startFn(); return; }
    deployBusy = true;
    if (deployKickerEl) deployKickerEl.textContent = t('loading');
    if (deployTitleEl) deployTitleEl.textContent = titleText;
    if (deploySubEl) deploySubEl.textContent = t('deploySub');
    if (deployTipEl) deployTipEl.textContent = t(DEPLOY_TIPS[Math.floor(Math.random() * DEPLOY_TIPS.length)]);
    if (deployFillEl) deployFillEl.style.width = '0%';
    if (deployPctEl) deployPctEl.textContent = '0%';
    deployOverlay.classList.add('active');
    const t0 = performance.now();
    const DUR = 850;
    function step() {
        const p = Math.min(1, (performance.now() - t0) / DUR);
        const eased = 1 - Math.pow(1 - p, 2.2);
        if (deployFillEl) deployFillEl.style.width = (eased * 100).toFixed(1) + '%';
        if (deployPctEl) deployPctEl.textContent = Math.round(eased * 100) + '%';
        if (p < 1) { requestAnimationFrame(step); return; }
        setTimeout(() => {
            startFn();
            deployOverlay.classList.remove('active');
            setTimeout(() => { deployBusy = false; }, 340);
        }, 110);
    }
    requestAnimationFrame(step);
}

// ============ УРОВНИ ============
let levelBalls = [], levelTimerId = null, levelTimeLeft = 10, levelActive = false, currentLevelNum = 1;
function createLevelBall(type, x, z) {
    const cfg = {
        normal: { color: 0xbb77ff, emissive: 0x440066 },
        golden: { color: 0xffd966, emissive: 0x553300 },
        bomb: { color: 0xff5555, emissive: 0x550000 },
        lightning: { color: 0x44ff44, emissive: 0x004400 }
    }[type];
    const sphere = new THREE.Mesh(BALL_GEO, getBallMaterial(cfg.color, cfg.emissive));
    sphere.castShadow = true; sphere.receiveShadow = true;
    sphere.position.set(x, BALL_Y_FLOOR, z);
    sphere.scale.set(0, 0, 0);
    sphere.userData = { type, targetScale: 1, activated: false, isLevelBall: true, seed: Math.random() * Math.PI * 2, spawnDrop: 0.8, baseEI: 0.9 };
    if (type === 'lightning' || type === 'golden') {
        const haloMat = new THREE.SpriteMaterial({
            map: glowTexture, color: type === 'lightning' ? 0x66ff88 : 0xffe9a8,
            transparent: true, opacity: 0.28,
            blending: THREE.AdditiveBlending, depthWrite: false
        });
        const halo = new THREE.Sprite(haloMat);
        halo.scale.set(1.1, 1.1, 1);
        sphere.add(halo);
        sphere.userData.halo = halo;
    }
    gameGroup.add(sphere); levelBalls.push(sphere);
    spawnRing(x, z, cfg.color);
    return sphere;
}
function spawnLevelBalls(count = 21, types = null) {
    if (!types) {
        types = [];
        for (let i = 0; i < 13; i++) types.push('normal');
        for (let i = 0; i < 6; i++) types.push('golden');
        for (let i = 0; i < 2; i++) types.push('lightning');
    }
    if (types.length === 0) for (let i = 0; i < count; i++) types.push('lightning');
    for (let i = types.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [types[i], types[j]] = [types[j], types[i]];
    }
    const positions = [];
    types.forEach(type => {
        let att = 0, x, z, ok;
        do {
            x = (Math.random() * 2 - 1) * 4.2;
            z = (Math.random() * 2 - 1) * 4.2 * 0.7;
            ok = true;
            for (let p of positions) if (Math.sqrt((p.x - x) ** 2 + (p.z - z) ** 2) < 1.4) { ok = false; break; }
            att++;
        } while (!ok && att < 30);
        positions.push({ x, z });
        createLevelBall(type, x, z);
    });
}
function prepareStartLevel() {
    initAudio();
    mainMenu.classList.remove('active');
    modeSelect.classList.remove('active');
    levelsMenu.classList.remove('active');
    clearBalls();
    clearEffects();
    isReloading = false;
    continuousShots = 0;
    initMagazine();
    balls = []; particles = []; levelBalls = [];
    levelResult.classList.remove('active');
}
function startLevel1() {
    prepareStartLevel();
    hud.classList.remove('active'); decorGroup.visible = false;
    gameActive = false; levelActive = true; currentLevelNum = 1; levelTimeLeft = 10;
    setGunVisible(true);
    spawnLevelBalls();
    levelHud.classList.add('active');
    levelTimer.textContent = levelTimeLeft;
    levelExtraInfo.textContent = tf('remaining', { n: levelBalls.length });
    levelTimerId = setInterval(() => {
        levelTimeLeft--; levelTimer.textContent = levelTimeLeft;
        if (levelTimeLeft <= 0) {
            if (levelBalls.filter(b => b.parent).length === 0) levelSuccess(1);
            else levelFail(1);
        }
    }, 1000);
    if (!animFrameId) animateGame();
}
function startLevel2() {
    prepareStartLevel();
    hud.classList.add('active'); decorGroup.visible = false;
    gameActive = true; levelActive = false; currentLevelNum = 2;
    setGunVisible(true);
    timeLeft = 15; lives = 3; currentStars = 0;
    updateHUD(); startMusic();
    let sm = 1.0;
    if (settings.difficulty === 'easy') sm = 0.7;
    else if (settings.difficulty === 'hard') sm = 1.3;
    levelTimerId = setInterval(() => {
        timeLeft--; updateHUD();
        if (timeLeft <= 0) { if (lives > 0) levelSuccess(2); else levelFail(2); }
    }, 1000);
    spawnTimerId = setTimeout(function loop() {
        if (!gameActive) return;
        if (balls.length < MAX_BALLS_HARDCORE) spawnClassicBall(sm);
        const diff = difficultySettings[settings.difficulty];
        spawnTimerId = setTimeout(loop, diff.minSpawnInterval * 0.35 * 1000);
    }, 100);
    if (!animFrameId) animateGame();
}
function startLevel3() {
    prepareStartLevel();
    hud.classList.remove('active'); decorGroup.visible = false;
    gameActive = false; levelActive = true; currentLevelNum = 3; levelTimeLeft = 5;
    setGunVisible(true);
    const types = []; for (let i = 0; i < 30; i++) types.push('lightning');
    spawnLevelBalls(30, types);
    levelHud.classList.add('active');
    levelTimer.textContent = levelTimeLeft;
    levelExtraInfo.textContent = tf('remaining', { n: levelBalls.length });
    levelTimerId = setInterval(() => {
        levelTimeLeft--; levelTimer.textContent = levelTimeLeft;
        if (levelTimeLeft <= 0) {
            if (levelBalls.filter(b => b.parent).length === 0) levelSuccess(3);
            else levelFail(3);
        }
    }, 1000);
    if (!animFrameId) animateGame();
}
function levelSuccess(num) {
    clearInterval(levelTimerId);
    if (num === 2) { clearTimeout(spawnTimerId); stopMusic(); gameActive = false; }
    levelActive = false;
    let reward = 0, isReplay = false;
    if (num === 1) { if (level1Completed) { reward = 50; isReplay = true; } else { reward = 400; level1Completed = true; } }
    else if (num === 2) { if (level2Completed) { reward = 100; isReplay = true; } else { reward = 600; level2Completed = true; } }
    else if (num === 3) { if (level3Completed) { reward = 50; isReplay = true; } else { reward = 600; level3Completed = true; } }
    starsBalance += reward;
    saveState(); updateStarsDisplay(); updateLevelStatuses();
    resultTitle.textContent = t('success');
    resultTitle.className = 'title success';
    resultSub.textContent = tf(isReplay ? 'rewardReplay' : 'reward', { n: reward });
    resultBtn.textContent = t('continueBtn');
    levelResult.classList.add('active');
    levelHud.classList.remove('active');
    if (num === 2) hud.classList.remove('active');
    setGunVisible(false);
    updateUpgradesUI();
    decorGroup.visible = true;
    levelBalls = [];
    clearBalls();

    if (num === 3) unlockAchievement('comp_almost_died');
    if (num === 2) {
        const lvl = getAutomatikaLevel();
        if (lvl >= 2 && achievements['impossible']) unlockAchievement('better');
    }
}
function levelFail(num) {
    clearInterval(levelTimerId);
    if (num === 2) { clearTimeout(spawnTimerId); stopMusic(); gameActive = false; }
    levelActive = false;
    resultTitle.textContent = t('fail');
    resultTitle.className = 'title fail';
    const rem = levelBalls ? levelBalls.filter(b => b.parent).length : 0;
    resultSub.textContent = (num === 3) ? tf('failLightning', { n: rem }) : tf('failBalls', { n: rem });
    resultBtn.textContent = t('retry');
    levelResult.classList.add('active');
    levelHud.classList.remove('active');
    if (num === 2) hud.classList.remove('active');
    setGunVisible(false);
    decorGroup.visible = true;
    levelBalls = [];
    clearBalls();

    if (num === 2 && getAutomatikaLevel() === 0) {
        unlockAchievement('impossible');
    }
}
const origEndClassic = endClassicGame;
endClassicGame = function () {
    if (currentLevelNum === 2 && gameActive) {
        if (lives <= 0) levelFail(2);
        else if (timeLeft <= 0) levelSuccess(2);
        return;
    }
    origEndClassic.call(this);
};

// ============ НАВИГАЦИЯ ============
playBtn.addEventListener('click', () => {
    menuScore.classList.add('hidden');
    playBtn.textContent = t('play');
    mainMenu.classList.remove('active');
    modeSelect.classList.add('active');
    levelsMenu.classList.remove('active');
});
modeBack.addEventListener('click', () => { modeSelect.classList.remove('active'); mainMenu.classList.add('active'); });
levelBtn.addEventListener('click', () => { modeSelect.classList.remove('active'); levelsMenu.classList.add('active'); updateLevelStatuses(); });
levelsBack.addEventListener('click', () => { levelsMenu.classList.remove('active'); modeSelect.classList.add('active'); });
level1Card.addEventListener('click', () => { if (levelActive) return; deployThen(t('level1'), startLevel1); });
level2Card.addEventListener('click', () => { if (levelActive) return; deployThen(t('level2'), startLevel2); });
level3Card.addEventListener('click', () => { if (levelActive) return; deployThen(t('level3'), startLevel3); });
classicBtn.addEventListener('click', () => deployThen(t('modeClassic'), startClassicGame));
resultBtn.addEventListener('click', () => {
    levelResult.classList.remove('active');
    levelsMenu.classList.add('active');
    modeSelect.classList.remove('active');
    mainMenu.classList.remove('active');
    updateLevelStatuses();
    decorGroup.visible = true;
});

upgradesBtn.addEventListener('click', () => { updateUpgradesUI(); upgradesOverlay.classList.add('active'); });
upgradesClose.addEventListener('click', () => upgradesOverlay.classList.remove('active'));
upgradesOverlay.addEventListener('click', e => { if (e.target === upgradesOverlay) upgradesOverlay.classList.remove('active'); });

['lightningBoost', 'goldFever', 'doubleChain', 'automatika'].forEach(name => {
    const btn = document.getElementById('btn-' + name);
    const toggle = document.getElementById('toggle-' + name);
    if (btn) btn.addEventListener('click', () => tryUpgrade(name));
    if (toggle) toggle.addEventListener('click', e => { e.stopPropagation(); toggleUpgrade(name); });
});

achievementsBtn.addEventListener('click', () => { updateAchievementsUI(); achievementsOverlay.classList.add('active'); });
achievementsClose.addEventListener('click', () => achievementsOverlay.classList.remove('active'));
achievementsOverlay.addEventListener('click', e => { if (e.target === achievementsOverlay) achievementsOverlay.classList.remove('active'); });

starsCounter.addEventListener('click', () => bonusOverlay.classList.add('active'));
bonusClose.addEventListener('click', () => bonusOverlay.classList.remove('active'));
bonusOverlay.addEventListener('click', e => { if (e.target === bonusOverlay) bonusOverlay.classList.remove('active'); });
document.querySelectorAll('.bonus-btn').forEach(btn => {
    btn.addEventListener('click', function () { addBonusStars(parseInt(this.dataset.amount, 10)); bonusOverlay.classList.remove('active'); });
});

settingsBtn.addEventListener('click', () => {
    durationSelect.value = settings.duration; livesSelect.value = settings.lives;
    difficultySelect.value = settings.difficulty; spawnModeSelect.value = settings.spawnMode;
    graphicsQualitySelect.value = settings.graphicsQuality;
    if (renderScaleSelect) renderScaleSelect.value = settings.renderScale || 'auto';
    if (fpsSelect) fpsSelect.value = settings.fpsCounter ? '1' : '0';
    if (langSelect) langSelect.value = lang;
    fillEballInfo();
    settingsModal.classList.add('active');
});
saveSettingsBtn.addEventListener('click', () => {
    settings.duration = parseInt(durationSelect.value);
    settings.lives = parseInt(livesSelect.value);
    settings.difficulty = difficultySelect.value;
    settings.spawnMode = spawnModeSelect.value;
    settings.graphicsQuality = graphicsQualitySelect.value;
    if (renderScaleSelect) settings.renderScale = renderScaleSelect.value;
    if (fpsSelect) settings.fpsCounter = fpsSelect.value === '1';
    if (langSelect) setLang(langSelect.value);
    saveState();
    applyGraphicsQuality();
    setRenderScaleMode(settings.renderScale || 'auto');
    refreshFpsHud();
    settingsModal.classList.remove('active');
});
settingsModal.addEventListener('click', e => { if (e.target === settingsModal) settingsModal.classList.remove('active'); });
resetProgressBtn.addEventListener('click', resetProgress);

tutorialBtn.addEventListener('click', () => tutorialOverlay.classList.add('active'));
tutorialClose.addEventListener('click', () => tutorialOverlay.classList.remove('active'));
tutorialOverlay.addEventListener('click', e => { if (e.target === tutorialOverlay) tutorialOverlay.classList.remove('active'); });

if (langRuBtn) langRuBtn.addEventListener('click', () => setLang('ru'));
if (langEnBtn) langEnBtn.addEventListener('click', () => setLang('en'));

// ============ УПРАВЛЕНИЕ ============
renderer.domElement.addEventListener('pointerdown', e => {
    e.preventDefault();
    firingHeld = true;
    initAudio();
    if (gunActive) tryFire();
});
renderer.domElement.addEventListener('pointerup', () => {
    firingHeld = false;
    continuousShots = 0;
});
renderer.domElement.addEventListener('pointerleave', () => {
    firingHeld = false;
    continuousShots = 0;
});
renderer.domElement.addEventListener('pointermove', e => {
    mouseClientX = e.clientX;
    mouseClientY = e.clientY;
});

document.addEventListener('keydown', e => {
    if (e.key === 'b' || e.key === 'B' || e.key === 'и' || e.key === 'И') {
        if (canUseAutoMode() && getAutomatikaLevel() === 2) {
            machinegunAutoMode = !machinegunAutoMode;
            updateFireModeSwitch();
        }
    }
});

addEventListener('resize', () => {
    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    applyRenderScale();
});

// ============ BOOT-ЗАСТАВКА (постадийная анимация загрузки) ============
let bootDismissed = false;
const BOOT_STEPS = [
    { key: 'bootStep1', to: 18, ms: 430 },
    { key: 'bootStep2', to: 46, ms: 520 },
    { key: 'bootStep3', to: 72, ms: 430 },
    { key: 'bootStep4', to: 94, ms: 370 },
    { key: 'bootStep5', to: 100, ms: 250 }
];
function dismissBoot() {
    if (bootDismissed) return;
    bootDismissed = true;
    const b = document.getElementById('bootScreen');
    if (!b) return;
    b.classList.add('hide');
    setTimeout(() => { if (b.parentNode) b.parentNode.removeChild(b); }, 700);
}
function runBootSequence() {
    const bootEl = document.getElementById('bootScreen');
    if (!bootEl || !bootLogEl || !bootFillEl) { setTimeout(dismissBoot, 900); return; }
    const lines = BOOT_STEPS.map(st => {
        const div = document.createElement('div');
        div.className = 'boot-line';
        const dot = document.createElement('span'); dot.className = 'bl-dot';
        const txt = document.createElement('span'); txt.className = 'bl-txt'; txt.textContent = t(st.key);
        const ok = document.createElement('span'); ok.className = 'bl-ok';
        div.appendChild(dot); div.appendChild(txt); div.appendChild(ok);
        bootLogEl.appendChild(div);
        return div;
    });
    let pi = 0, progress = 0;
    let stepStart = performance.now();
    function frame() {
        if (bootDismissed) return;
        const now = performance.now();
        const st = BOOT_STEPS[pi];
        const k = Math.min(1, (now - stepStart) / st.ms);
        const from = pi === 0 ? 0 : BOOT_STEPS[pi - 1].to;
        const target = from + (st.to - from) * (1 - Math.pow(1 - k, 2));
        progress += (target - progress) * 0.3;
        bootFillEl.style.width = progress.toFixed(1) + '%';
        if (bootPctEl) bootPctEl.textContent = Math.round(progress) + '%';
        if (bootStepEl) bootStepEl.textContent = t(st.key);
        lines[pi].classList.add('on');
        if (k >= 1) {
            lines[pi].classList.remove('on');
            lines[pi].classList.add('done');
            pi++;
            stepStart = now;
            if (pi >= BOOT_STEPS.length) {
                bootFillEl.style.width = '100%';
                if (bootPctEl) bootPctEl.textContent = '100%';
                if (bootStepEl) bootStepEl.textContent = t('bootStep5');
                setTimeout(dismissBoot, 420);
                return;
            }
        }
        requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
    setTimeout(dismissBoot, 6000);   // подстраховка: никого не держим надолго
}

// ============ СТАРТ ============
if (EBALL) {
    if (bootLogoEl) bootLogoEl.textContent = 'E-Ball';
    if (bootSubEl) bootSubEl.textContent = 'Experimental · Vulkan';
    if (logoTitleEl) logoTitleEl.textContent = 'E-Ball';
    if (tbNameEl) tbNameEl.textContent = 'E-BALL';
    if (menuFootBrandEl) menuFootBrandEl.textContent = 'E-BALL';
}

applyI18n();
applyGraphicsQuality();
updateStarsDisplay();
updateUpgradesUI();
updateAchievementsUI();
updateAmmoHUD();
setRenderScaleMode(settings.renderScale || 'auto');
refreshFpsHud();
animateGame();
runBootSequence();

document.querySelectorAll('.ver-js').forEach(el => { el.textContent = GAME_VERSION; });

if (EBALL && EBALL_BACKEND === 'compat') {
    setTimeout(() => hint(t('vkFallback')), 3400);
}

if (firstRunDetected) {
    setTimeout(() => unlockAchievement('welcome'), 400);
}

console.log((EBALL ? 'E-Ball ' : '3D Balls ') + GAME_VERSION + ' — ' +
    (IS_ELECTRON ? (EBALL ? 'windows experimental build (ANGLE/Vulkan)' : 'windows build') : 'web build'));
