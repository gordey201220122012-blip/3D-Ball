// ============ THREE.JS ============
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
const BASE_PR = Math.min(window.devicePixelRatio || 1, 2);
renderer.setPixelRatio(BASE_PR);
renderer.setSize(container.clientWidth, container.clientHeight, false);

// Строка рендера WebGL (для E-Ball: показываем фактический бэкенд ANGLE)
let GL_RENDERER_STRING = '';
try {
    const _gl = renderer.getContext();
    const _dbg = _gl.getExtension('WEBGL_debug_renderer_info');
    GL_RENDERER_STRING = String(_dbg ? _gl.getParameter(_dbg.UNMASKED_RENDERER_WEBGL) : _gl.getParameter(_gl.RENDERER));
} catch (e) {}
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.shadowMap.bias = 0.0001;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
container.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x06090d);
scene.fog = new THREE.Fog(0x06090d, 9, 22);
const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 60);
const CAM_BASE = new THREE.Vector3(0, 6, 12);
camera.position.copy(CAM_BASE);
camera.lookAt(0, 0, 0);

const ambientLight = new THREE.AmbientLight(0x404080, 0.0);
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0xe8f2ff, 1.25);
dirLight.position.set(5, 12, 5);
dirLight.castShadow = true; dirLight.receiveShadow = true;
dirLight.shadow.mapSize.width = 2048; dirLight.shadow.mapSize.height = 2048;
dirLight.shadow.camera.near = 0.5; dirLight.shadow.camera.far = 25;
dirLight.shadow.camera.left = -6; dirLight.shadow.camera.right = 6;
dirLight.shadow.camera.top = 6; dirLight.shadow.camera.bottom = -6;
scene.add(dirLight);

const fillLight = new THREE.DirectionalLight(0x4466aa, 0.6);
fillLight.position.set(-4, 3, -4); scene.add(fillLight);

const backLight = new THREE.PointLight(0xffaa44, 0.35, 15);
backLight.position.set(-2, 1, -6); scene.add(backLight);

const accentLight1 = new THREE.PointLight(0x3b9eff, 0.55, 11);
accentLight1.position.set(3, 2, 3); scene.add(accentLight1);

const accentLight2 = new THREE.PointLight(0x8fb7ff, 0.5, 10);
accentLight2.position.set(-3, 2, 4); scene.add(accentLight2);

const pmremGenerator = new THREE.PMREMGenerator(renderer);
const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
scene.environment = envTexture;
pmremGenerator.dispose();

let reflectorFloor = new Reflector(new THREE.PlaneGeometry(10, 10), {
    clipBias: 0.003,
    textureWidth: innerWidth * 0.5,
    textureHeight: innerHeight * 0.5,
    color: 0x708196, recursion: 1
});
reflectorFloor.rotation.x = -Math.PI / 2;
reflectorFloor.position.y = -0.5;
reflectorFloor.receiveShadow = true;
scene.add(reflectorFloor);

const simpleFloor = new THREE.Mesh(
    new THREE.PlaneGeometry(10, 10),
    new THREE.MeshStandardMaterial({ color: 0x0c0f16, roughness: 0.85, metalness: 0.25 })
);
simpleFloor.rotation.x = -Math.PI / 2;
simpleFloor.position.y = -0.5;
simpleFloor.receiveShadow = true;
scene.add(simpleFloor);

const composer = new EffectComposer(renderer);
const renderPass = new RenderPass(scene, camera);
composer.addPass(renderPass);
const bloomPass = new UnrealBloomPass(
    new THREE.Vector2(innerWidth, innerHeight),
    0.55, 0.35, 0.12
);
composer.addPass(bloomPass);

// ============ МАСШТАБ РЕНДЕРА (меньшее разрешение + сглаженный апскейл) ============
// Рендерим в уменьшенный буфер, браузер растягивает canvas с билинейным сглаживанием.
let renderScaleCeiling = 1.0;   // максимум из настроек
let dynamicScale = 1.0;         // текущий множитель (0.5 .. ceiling)
let drGoodStreak = 0;
function currentRenderScale() { return dynamicScale; }
function applyRenderScale() {
    const pr = BASE_PR * dynamicScale;
    const w = container.clientWidth || innerWidth;
    const h = container.clientHeight || innerHeight;
    renderer.setPixelRatio(pr);
    renderer.setSize(w, h, false);
    composer.setPixelRatio(pr);
    composer.setSize(w, h);
    try {
        const rt = reflectorFloor.getRenderTarget();
        if (rt) rt.setSize(Math.max(2, Math.round(w * 0.5 * dynamicScale)), Math.max(2, Math.round(h * 0.5 * dynamicScale)));
    } catch (e) {}
}
function setRenderScaleMode(mode) {
    renderScaleCeiling = (mode === '1' || mode === '0.75' || mode === '0.5') ? parseFloat(mode) : 1.0;
    dynamicScale = (mode === 'auto') ? Math.min(dynamicScale, renderScaleCeiling) : renderScaleCeiling;
    drGoodStreak = 0;
    applyRenderScale();
}

const gameGroup = new THREE.Group(); scene.add(gameGroup);
const decorGroup = new THREE.Group(); scene.add(decorGroup);
const effectGroup = new THREE.Group(); scene.add(effectGroup);

// Трассировочная сетка арены (лёгкий декор пола)
const gridHelper = new THREE.GridHelper(10, 20, 0x24313f, 0x131a24);
gridHelper.position.y = -0.495;
gridHelper.material.transparent = true;
gridHelper.material.opacity = 0.5;
decorGroup.add(gridHelper);

const starsGeo = new THREE.BufferGeometry();
const starsColors = new Float32Array(600 * 3), starsPosArr = new Float32Array(600 * 3);
for (let i = 0; i < 600; i++) {
    const r = 5 + Math.random() * 15, theta = Math.random() * Math.PI * 2, phi = Math.random() * Math.PI - Math.PI / 2;
    starsPosArr[i * 3] = Math.cos(theta) * Math.cos(phi) * r;
    starsPosArr[i * 3 + 1] = Math.sin(phi) * r * 0.5 + 2;
    starsPosArr[i * 3 + 2] = Math.sin(theta) * Math.cos(phi) * r;
    const c = Math.random();
    const col = c < 0.72 ? new THREE.Color(0x3b9eff) : (c < 0.9 ? new THREE.Color(0xbfe0ff) : new THREE.Color(0x8fb7ff));
    starsColors[i * 3] = col.r; starsColors[i * 3 + 1] = col.g; starsColors[i * 3 + 2] = col.b;
}
starsGeo.setAttribute('position', new THREE.BufferAttribute(starsPosArr, 3));
starsGeo.setAttribute('color', new THREE.BufferAttribute(starsColors, 3));
const starsMat = new THREE.PointsMaterial({
    size: 0.11, vertexColors: true, blending: THREE.AdditiveBlending,
    depthWrite: false, sizeAttenuation: true, transparent: true, opacity: 0.8
});
const starPoints = new THREE.Points(starsGeo, starsMat);
decorGroup.add(starPoints);

// Декоративные орбитальные шары (меню) — сдержанная палитра
const decorBalls = [];
const decorPalette = [0x2f6fd0, 0x3b9eff, 0x7fc4ff, 0x18355e, 0x9db8d8];
for (let i = 0; i < 10; i++) {
    const geo = new THREE.SphereGeometry(0.3 + Math.random() * 0.4, 32, 32);
    const mat = new THREE.MeshPhysicalMaterial({
        color: decorPalette[i % decorPalette.length],
        emissive: decorPalette[i % decorPalette.length],
        emissiveIntensity: 0.18,
        roughness: 0.18, metalness: 0.7,
        clearcoat: 0.6, clearcoatRoughness: 0.3,
        envMap: envTexture, envMapIntensity: 1.3
    });
    const ball = new THREE.Mesh(geo, mat);
    const angle = Math.random() * Math.PI * 2, radius = 2.2 + Math.random() * 3.0;
    ball.position.set(Math.cos(angle) * radius, 0.2 + Math.random() * 1.2, Math.sin(angle) * radius);
    ball.castShadow = true; ball.receiveShadow = true;
    decorGroup.add(ball);
    decorBalls.push({
        mesh: ball, speed: 0.002 + Math.random() * 0.01,
        angle, radius, centerY: 0.2 + Math.random() * 1.2,
        ampY: 0.1 + Math.random() * 0.2
    });
}

// Парящие кольца арены (декор меню)
const decorRings = [];
const ringAccentMat = new THREE.MeshStandardMaterial({
    color: 0x2f81f7, emissive: 0x1a4d8f, emissiveIntensity: 1.1,
    metalness: 0.6, roughness: 0.3, transparent: true, opacity: 0.85
});
[[4.6, 0.35], [5.4, 0.95], [6.2, 1.6]].forEach(([radius, y], idx) => {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.022, 8, 96), ringAccentMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = y;
    decorGroup.add(ring);
    decorRings.push({ mesh: ring, speed: (idx % 2 ? -1 : 1) * (0.05 + idx * 0.02) });
});

function createGlowTexture() {
    const c = document.createElement('canvas');
    c.width = 64; c.height = 64;
    const cx = c.getContext('2d');
    const g = cx.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(0.3, 'rgba(255,255,255,0.8)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    cx.fillStyle = g; cx.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
}
const glowTexture = createGlowTexture();

// ============ ПУЛЫ ЭФФЕКТОВ (анти-фриз: ноль аллокаций в игровом кадре) ============
function makePool(createFn) {
    const free = [];
    return {
        acquire() { const o = (free.length ? free.pop() : createFn()); o.visible = true; return o; },
        release(o) { o.visible = false; free.push(o); }
    };
}
function releaseEffect(obj) {
    if (!obj.visible) return;
    const pool = obj.userData && obj.userData.pool;
    if (pool) { obj.visible = false; pool.release(obj); }
    else if (obj.parent) obj.parent.remove(obj);
}

// Плоские частицы (искры взрывов, хвосты трассеров, искры молний)
const _PART_GEO = new THREE.PlaneGeometry(1, 1);
function _createPlaneFx() {
    const m = new THREE.Mesh(_PART_GEO, new THREE.MeshBasicMaterial({
        map: glowTexture, transparent: true, opacity: 1,
        blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide
    }));
    m.visible = false; m.frustumCulled = false;
    effectGroup.add(m);
    m.userData = { pool: planeFxPool, baseScale: 1, age: 0, life: 1, type: 'bit', rotSpeed: 0, velocity: new THREE.Vector3() };
    return m;
}
const planeFxPool = makePool(_createPlaneFx);
function spawnParticle(x, y, z, color, size, life, vx, vy, vz, rotSpeed, type) {
    const m = planeFxPool.acquire();
    m.position.set(x, y, z);
    m.material.color.set(color);
    m.material.opacity = 1;
    m.scale.set(size, size, size);
    const u = m.userData;
    u.baseScale = size; u.age = 0; u.life = life;
    u.type = type || 'bit'; u.rotSpeed = rotSpeed || 0;
    u.velocity.set(vx || 0, vy || 0, vz || 0);
    particles.push(m);
    return m;
}

// Кольца (импульс появления шарика + кольцо взрыва)
const RING_GEO_BIG = new THREE.RingGeometry(0.3, 0.42, 40);
const RING_GEO_SMALL = new THREE.RingGeometry(0.05, 0.16, 40);
function _createRingFx() {
    const m = new THREE.Mesh(RING_GEO_SMALL, new THREE.MeshBasicMaterial({
        transparent: true, opacity: 0.85,
        blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide
    }));
    m.visible = false; m.frustumCulled = false;
    effectGroup.add(m);
    m.userData = { pool: ringFxPool, baseScale: 1, age: 0, life: 0.6, type: 'ring', velocity: null };
    return m;
}
const ringFxPool = makePool(_createRingFx);
function spawnRingFx(geo, x, y, z, colorHex, life) {
    const m = ringFxPool.acquire();
    m.geometry = geo;
    m.material.color.set(colorHex);
    m.material.opacity = 0.85;
    m.position.set(x, y, z);
    m.scale.set(1, 1, 1);
    m.userData.age = 0;
    m.userData.life = life || 0.6;
    particles.push(m);
    return m;
}

// Круглые вспышки в точке взрыва
function _createFlashFx() {
    const m = new THREE.Mesh(new THREE.CircleGeometry(0.12, 24), new THREE.MeshBasicMaterial({
        transparent: true, opacity: 0.9,
        blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide
    }));
    m.visible = false; m.frustumCulled = false;
    effectGroup.add(m);
    m.userData = { pool: flashFxPool, baseScale: 1, age: 0, life: 0.3, type: 'flash', velocity: null };
    return m;
}
const flashFxPool = makePool(_createFlashFx);
function spawnFlashFx(x, y, z, colorHex) {
    const m = flashFxPool.acquire();
    m.material.color.set(colorHex);
    m.material.opacity = 0.9;
    m.position.set(x, y, z);
    m.scale.set(1, 1, 1);
    m.lookAt(camera.position);
    m.userData.age = 0;
    m.userData.life = 0.3;
    particles.push(m);
    return m;
}

// Спрайты (вспышки выстрелов и попаданий)
function _createSpriteFx() {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowTexture, transparent: true, opacity: 1,
        blending: THREE.AdditiveBlending, depthWrite: false
    }));
    s.visible = false;
    effectGroup.add(s);
    s.userData = { pool: spriteFxPool, baseScale: 0.5, age: 0, life: 0.1, type: 'muzzle', isSprite: true, velocity: null };
    return s;
}
const spriteFxPool = makePool(_createSpriteFx);
function spawnSpriteFx(x, y, z, color, opacity, size, life, type) {
    const s = spriteFxPool.acquire();
    s.material.color.set(color);
    s.material.opacity = opacity;
    s.position.set(x, y, z);
    s.scale.set(size, size, 1);
    const u = s.userData;
    u.baseScale = size; u.age = 0; u.life = life; u.type = type;
    particles.push(s);
    return s;
}

// Линии молний
const _boltMat = new THREE.LineBasicMaterial({ color: 0x44ff44, transparent: true, opacity: 0.9 });
const BOLT_MAX_PTS = 8;
function _createBoltLine() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(BOLT_MAX_PTS * 3), 3));
    g.setDrawRange(0, 0);
    const l = new THREE.Line(g, _boltMat);
    l.visible = false; l.frustumCulled = false;
    effectGroup.add(l);
    l.userData = { pool: boltLinePool, velocity: null };
    return l;
}
const boltLinePool = makePool(_createBoltLine);
function spawnBoltLine(pts) {
    const l = boltLinePool.acquire();
    const attr = l.geometry.attributes.position;
    const n = Math.min(pts.length, BOLT_MAX_PTS);
    for (let i = 0; i < n; i++) attr.setXYZ(i, pts[i].x, pts[i].y, pts[i].z);
    attr.needsUpdate = true;
    l.geometry.setDrawRange(0, n);
    setTimeout(() => releaseEffect(l), 300);
}

// Снаряды (ядро + оболочка + гало; без динамических источников света — стабильные шейдеры)
const PROJ_GEO_CORE = new THREE.SphereGeometry(0.06, 10, 10);
const PROJ_GEO_SHELL = new THREE.SphereGeometry(0.15, 10, 10);
function _createProjectileFx() {
    const core = new THREE.Mesh(PROJ_GEO_CORE, new THREE.MeshBasicMaterial({ color: 0xeaf6ff }));
    const shell = new THREE.Mesh(PROJ_GEO_SHELL, new THREE.MeshBasicMaterial({
        color: 0x3b9eff, transparent: true, opacity: 0.34,
        blending: THREE.AdditiveBlending, depthWrite: false
    }));
    core.add(shell);
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowTexture, color: 0x7fc4ff, transparent: true, opacity: 0.78,
        blending: THREE.AdditiveBlending, depthWrite: false
    }));
    halo.scale.set(0.55, 0.55, 1);
    core.add(halo);
    core.visible = false; core.frustumCulled = false;
    effectGroup.add(core);
    core.userData = { pool: projectilePool, shell, halo, velocity: new THREE.Vector3(), life: 2, age: 0, trailAcc: 0 };
    return core;
}
const projectilePool = makePool(_createProjectileFx);

// ============ ПУШКА (переработанная модель) ============
const GUN_POS = new THREE.Vector3(0, 0.3, 5.3);
const BALL_Y_FLOOR = -0.08;

const gunGroup = new THREE.Group();
gunGroup.position.copy(GUN_POS);
gunGroup.visible = false;   // в главном меню пушки нет — она появляется только в бою
scene.add(gunGroup);
let gunActive = false;
function setGunVisible(v) {
    gunActive = v;
    gunGroup.visible = v;
    if (!v) { gunYaw = Math.PI; gunPitch = -0.3; targetYaw = Math.PI; targetPitch = -0.3; gunRecoil = 0; }
}

const gunDarkMat = new THREE.MeshStandardMaterial({
    color: 0x1c232d, metalness: 0.9, roughness: 0.38,
    envMap: envTexture, envMapIntensity: 1.0
});
const gunMetalMat = new THREE.MeshStandardMaterial({
    color: 0x414c5a, metalness: 0.95, roughness: 0.26,
    envMap: envTexture, envMapIntensity: 1.15
});
const gunAccentMat = new THREE.MeshStandardMaterial({
    color: 0x3b9eff, emissive: 0x1f6feb, emissiveIntensity: 1.6,
    metalness: 0.5, roughness: 0.3
});

// Основание турели
const baseMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.31, 0.16, 24), gunDarkMat);
baseMesh.castShadow = true; baseMesh.receiveShadow = true;
gunGroup.add(baseMesh);

const baseRing = new THREE.Mesh(new THREE.TorusGeometry(0.27, 0.02, 12, 48), gunAccentMat);
baseRing.rotation.x = Math.PI / 2;
baseRing.position.y = 0.09;
gunGroup.add(baseRing);

// Вращающаяся часть
const gunRotator = new THREE.Group();
gunRotator.rotation.order = 'YXZ';
gunGroup.add(gunRotator);

// Группа корпуса (цель анимации отдачи)
const bodyGroup = new THREE.Group();
gunRotator.add(bodyGroup);

const housing = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.2, 0.5), gunMetalMat);
housing.position.set(0, 0.1, 0.02);
housing.castShadow = true;
bodyGroup.add(housing);

const topRail = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.05, 0.44), gunDarkMat);
topRail.position.set(0, 0.225, 0.02);
topRail.castShadow = true;
bodyGroup.add(topRail);

[-0.185, 0.185].forEach(x => {
    const side = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.13, 0.36), gunDarkMat);
    side.position.set(x, 0.1, 0.0);
    side.castShadow = true;
    bodyGroup.add(side);
    const strip = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.012, 0.3), gunAccentMat);
    strip.position.set(x * 1.04, 0.155, 0.0);
    bodyGroup.add(strip);
});

const underFeed = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.1, 0.22), gunDarkMat);
underFeed.position.set(0, 0.02, 0.22);
underFeed.castShadow = true;
bodyGroup.add(underFeed);

// Ствол
const barrelGroup = new THREE.Group();
barrelGroup.position.set(0, 0.14, 0.28);
bodyGroup.add(barrelGroup);

const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.06, 0.74, 20), gunMetalMat);
barrel.rotation.x = Math.PI / 2;
barrel.position.set(0, 0, 0.37);
barrel.castShadow = true;
barrelGroup.add(barrel);

[0.2, 0.34, 0.48].forEach(z => {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.011, 10, 28), gunDarkMat);
    ring.position.set(0, 0, z);
    barrelGroup.add(ring);
});

const brake = new THREE.Mesh(new THREE.CylinderGeometry(0.082, 0.074, 0.1, 18), gunDarkMat);
brake.rotation.x = Math.PI / 2;
brake.position.set(0, 0, 0.75);
brake.castShadow = true;
barrelGroup.add(brake);

const muzzleRing = new THREE.Mesh(new THREE.TorusGeometry(0.062, 0.014, 10, 24), gunAccentMat);
muzzleRing.position.set(0, 0, 0.81);
barrelGroup.add(muzzleRing);

const muzzle = new THREE.Object3D();
muzzle.position.set(0, 0, 0.84);
barrelGroup.add(muzzle);

// Свет дульной вспышки (переиспользуемый)
const muzzleFlashLight = new THREE.PointLight(0x9fd0ff, 0, 4);
muzzle.add(muzzleFlashLight);

// Спрайт-шкала магазина/перезарядки
const barCanvas = document.createElement('canvas');
barCanvas.width = 320; barCanvas.height = 40;
const barCtx = barCanvas.getContext('2d');
const barTexture = new THREE.CanvasTexture(barCanvas);
barTexture.minFilter = THREE.LinearFilter;

const barSpriteMat = new THREE.SpriteMaterial({
    map: barTexture,
    transparent: true,
    depthWrite: false,
    depthTest: false
});
const barSprite = new THREE.Sprite(barSpriteMat);
barSprite.scale.set(0.72, 0.09, 1);
barSprite.position.set(0, 0.36, 0.3);
barSprite.renderOrder = 999;
gunRotator.add(barSprite);

let lastBarProgress = -1;
let lastBarColor = '';

function redrawReloadBar(progress, colorHex) {
    if (Math.abs(progress - lastBarProgress) < 0.012 && colorHex === lastBarColor) return;
    lastBarProgress = progress;
    lastBarColor = colorHex;

    const W = barCanvas.width, H = barCanvas.height;
    barCtx.clearRect(0, 0, W, H);

    barCtx.strokeStyle = 'rgba(59,158,255,0.6)';
    barCtx.lineWidth = 3;
    barCtx.strokeRect(1.5, 1.5, W - 3, H - 3);

    barCtx.fillStyle = 'rgba(8,11,16,0.92)';
    barCtx.fillRect(3, 3, W - 6, H - 6);

    const fillW = Math.max(0, Math.floor((W - 8) * progress));
    if (fillW > 0) {
        const grad = barCtx.createLinearGradient(0, 0, W, 0);
        if (colorHex === 'reload') {
            grad.addColorStop(0, '#e8a33d');
            grad.addColorStop(1, '#f5cf7a');
        } else {
            grad.addColorStop(0, '#2f81f7');
            grad.addColorStop(1, '#7fc4ff');
        }
        barCtx.fillStyle = grad;
        barCtx.fillRect(4, 4, fillW, H - 8);
    }

    barCtx.shadowColor = (colorHex === 'reload') ? '#e8a33d' : '#3b9eff';
    barCtx.shadowBlur = 8;
    barCtx.strokeStyle = 'rgba(200,232,255,0.85)';
    barCtx.lineWidth = 2;
    barCtx.strokeRect(1.5, 1.5, W - 3, H - 3);
    barCtx.shadowBlur = 0;

    barTexture.needsUpdate = true;
}

// ============ СТРЕЛЬБА ============
let gunYaw = Math.PI, gunPitch = -0.3;
let targetYaw = Math.PI, targetPitch = -0.3;
const gunTurnSpeed = 10.0;
let gunRecoil = 0;

let isReloading = false;
let reloadStartTime = 0;
let reloadDuration = 300;
let magazine = 0;
let lastShotTime = 0;
let firingHeld = false;
let continuousShots = 0;

function initMagazine() {
    const max = getMagazineSize();
    if (max > 0) magazine = max;
}

function startReload(duration) {
    isReloading = true;
    reloadStartTime = performance.now();
    reloadDuration = duration;
    continuousShots = 0;
    sfxReload();
}

function updateReload() {
    if (!isReloading) return;
    if (performance.now() - reloadStartTime >= reloadDuration) {
        isReloading = false;
        if (getMagazineSize() > 0) magazine = getMagazineSize();
    }
}

const _ndc = new THREE.Vector2();
const _ray = new THREE.Raycaster();
const _aimPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -BALL_Y_FLOOR);
const _hitPoint = new THREE.Vector3();
function screenToPlane(clientX, clientY) {
    const w = container.clientWidth || innerWidth;
    const h = container.clientHeight || innerHeight;
    _ndc.x = (clientX / w) * 2 - 1;
    _ndc.y = -(clientY / h) * 2 + 1;
    _ray.setFromCamera(_ndc, camera);
    return _ray.ray.intersectPlane(_aimPlane, _hitPoint) ? _hitPoint : null;
}

let mouseClientX = innerWidth / 2, mouseClientY = innerHeight / 2;
function updateGunAim() {
    const target = screenToPlane(mouseClientX, mouseClientY);
    if (!target) return;
    const dx = target.x - GUN_POS.x;
    const dy = target.y - (GUN_POS.y + 0.14);
    const dz = target.z - GUN_POS.z;
    const yaw = Math.atan2(dx, dz);
    const horiz = Math.sqrt(dx * dx + dz * dz);
    const pitch = -Math.atan2(dy, horiz);
    targetYaw = yaw;
    targetPitch = Math.max(-0.9, Math.min(0.4, pitch));
}

function updateGunRotation(dt) {
    let dyaw = targetYaw - gunYaw;
    while (dyaw > Math.PI) dyaw -= Math.PI * 2;
    while (dyaw < -Math.PI) dyaw += Math.PI * 2;
    const maxRot = gunTurnSpeed * dt;
    if (Math.abs(dyaw) < maxRot) gunYaw = targetYaw;
    else gunYaw += Math.sign(dyaw) * maxRot;

    let dpitch = targetPitch - gunPitch;
    if (Math.abs(dpitch) < maxRot) gunPitch = targetPitch;
    else gunPitch += Math.sign(dpitch) * maxRot;

    // Отдача: пружинный возврат
    gunRecoil = Math.max(0, gunRecoil - dt * 6.5);
    const r = gunRecoil;
    bodyGroup.position.z = -r * 0.075;
    bodyGroup.rotation.x = r * 0.045;

    gunRotator.rotation.y = gunYaw;
    gunRotator.rotation.x = gunPitch;
}

function updateReloadBar() {
    let progress = 1;
    let colorKey = 'cyan';
    if (isReloading) {
        progress = Math.min(1, (performance.now() - reloadStartTime) / reloadDuration);
        colorKey = 'reload';
    } else if (getMagazineSize() > 0) {
        const max = getMagazineSize();
        progress = max > 0 ? magazine / max : 1;
    }
    redrawReloadBar(progress, colorKey);
    updateAmmoHUD(progress, colorKey);
}

let lastAmmoKey = '', lastAmmoMag = -1, lastAmmoWidth = -1;
function updateAmmoHUD(progress, colorKey) {
    if (!ammoHud) return;
    const max = getMagazineSize();
    if (max <= 0 || !gunActive) {
        ammoHud.classList.remove('on');
        lastAmmoKey = '';
        return;
    }
    ammoHud.classList.add('on');
    if (magazine !== lastAmmoMag || max !== lastAmmoMag) {
        lastAmmoMag = magazine;
        ammoMag.textContent = magazine;
        ammoMax.textContent = max;
    }
    const p = (progress !== undefined) ? progress : magazine / max;
    const w100 = p * 100;
    if (Math.abs(w100 - lastAmmoWidth) > 0.4) {
        lastAmmoWidth = w100;
        ammoFill.style.width = w100.toFixed(1) + '%';
    }
    ammoFill.classList.toggle('reloading', colorKey === 'reload');
    if (colorKey !== lastAmmoKey) {
        lastAmmoKey = colorKey;
        ammoState.textContent = (colorKey === 'reload') ? t('reloading') : t('ammo');
    }
}

const _muzzleWorld = new THREE.Vector3();
const _shotDir = new THREE.Vector3();
function fireProjectile() {
    sfxShoot();
    muzzle.getWorldPosition(_muzzleWorld);
    const target = screenToPlane(mouseClientX, mouseClientY);
    if (target) {
        _shotDir.copy(target).sub(_muzzleWorld).normalize();
    } else {
        _shotDir.set(Math.sin(gunYaw) * Math.cos(gunPitch), Math.sin(gunPitch), Math.cos(gunYaw) * Math.cos(gunPitch));
    }

    const core = projectilePool.acquire();
    core.position.copy(_muzzleWorld);
    const u = core.userData;
    u.velocity.copy(_shotDir).multiplyScalar(34);
    u.age = 0;
    u.life = 2.0;
    u.trailAcc = 0;
    projectiles.push(core);

    // Отдача и вспышка
    gunRecoil = 1;
    muzzleFlashLight.intensity = 3.2;
    spawnSpriteFx(_muzzleWorld.x, _muzzleWorld.y, _muzzleWorld.z, 0xbfe2ff, 0.95, 0.3, 0.09, 'muzzle');
}

function tryFire() {
    if (isReloading) return;
    const now = performance.now();
    const lvl = getAutomatikaLevel();

    if (lvl >= 1) {
        const isAutoFire = (lvl === 3) || (lvl === 2 && machinegunAutoMode);
        if (isAutoFire && now - lastShotTime < getFireDelay()) return;

        if (magazine <= 0) { startReload(getReloadDuration()); return; }
        fireProjectile();
        lastShotTime = now;
        magazine--;
        continuousShots++;
        if (lvl === 2 && machinegunAutoMode) unlockAchievement('technique');
        if (lvl === 3 && continuousShots >= 60) unlockAchievement('burn_me');
        if (magazine <= 0) {
            startReload(getReloadDuration());
        }
    } else {
        if (now - lastShotTime < 300) return;
        fireProjectile();
        lastShotTime = now;
        startReload(300);
    }
}
