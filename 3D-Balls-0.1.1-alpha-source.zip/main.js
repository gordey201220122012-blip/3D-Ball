// 3D Balls / E-Ball — 0.1.1-alpha — Electron main (Windows)
// E-Ball: экспериментальная сборка — рендер через Vulkan (ANGLE) с авто-фолбэком на D3D11,
// плюс калибровочный модуль, скомпилированный из языка Goose (goose-lang).
const { app, BrowserWindow, Menu } = require('electron');
const { spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');

let pkg = {};
try { pkg = require('./package.json'); } catch (e) {}
const IS_EBALL = pkg.productName === 'E-Ball';
const IS_WIN = process.platform === 'win32';
app.setAppUserModelId(IS_EBALL ? 'balls.eball.experimental' : 'balls.threedballs.game');

// ---- E-Ball: ANGLE -> Vulkan + защита от сбоя драйвера ----
// Логика: перед запуском с Vulkan ставим блокировку vk.lock.
// Если предыдущий запуск завершился аварийно (блокировка осталась) —
// этот запуск идёт в совместимом режиме (D3D11). Блокировка снимается
// только после чистого выхода, поэтому сбой GPU автоматически
// переключает игру на совместимый режим со следующего запуска.
let eballBackend = null;          // 'vulkan' | 'compat'
let eballLoadedOk = false;
let eballGpuCrash = false;
const eballLock = path.join(app.getPath('userData'), 'vk.lock');

if (IS_EBALL) {
    let useVulkan = true;
    try {
        if (fs.existsSync(eballLock)) {
            fs.rmSync(eballLock, { force: true });
            useVulkan = false;          // прошлый Vulkan-запуск упал — совместимый режим
        } else {
            fs.writeFileSync(eballLock, '1');
        }
    } catch (e) { /* userData недоступен — просто пробуем Vulkan */ }
    eballBackend = useVulkan ? 'vulkan' : 'compat';
    if (useVulkan) {
        app.commandLine.appendSwitch('use-angle', 'vulkan');
    }
    console.log('E-Ball: render backend =', eballBackend, '(ANGLE' + (useVulkan ? '/Vulkan' : ' default/D3D11') + ')');
    app.on('child-process-gone', (e, details) => {
        if (details && details.type === 'GPU') eballGpuCrash = true;
    });
    app.on('will-quit', () => {
        try {
            if (eballLoadedOk && !eballGpuCrash) fs.rmSync(eballLock, { force: true });
        } catch (e) {}
    });
}

function createWindow() {
    // E-Ball: калибровка Goose-модуля (eball-bench.exe, написан на goose-lang)
    let gooseMs = null;
    if (IS_EBALL) {
        const benchPath = path.join(path.dirname(process.execPath), 'eball-bench.exe');
        try {
            if (fs.existsSync(benchPath)) {
                const out = spawnSync(benchPath, [], { timeout: 8000, windowsHide: true, encoding: 'utf8' });
                const m = /GOOSE-OK ms=([0-9.]+)/.exec(String(out.stdout || '') + String(out.stderr || ''));
                if (m) gooseMs = Math.round(parseFloat(m[1]));
            }
        } catch (e) { /* модуль необязателен */ }
    }

    const opts = {
        width: 1280,
        height: 800,
        minWidth: 1000,
        minHeight: 620,
        backgroundColor: '#0b0e13',
        show: false,
        autoHideMenuBar: true,
        title: IS_EBALL ? 'E-Ball' : '3D Balls',
        icon: path.join(__dirname, 'icon.ico'),
        webPreferences: {
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
            spellcheck: false,
            backgroundThrottling: false
        }
    };
    if (IS_WIN) {
        opts.titleBarStyle = 'hidden';
        opts.titleBarOverlay = { color: '#0d1016', symbolColor: '#8fa0b5', height: 40 };
    }

    const win = new BrowserWindow(opts);
    Menu.setApplicationMenu(null);

    if (IS_EBALL) {
        win.webContents.once('did-finish-load', () => { eballLoadedOk = true; });
    }

    // Режим автоматического скриншота (для тестов сборки)
    const shotMode = process.env.GAME_SHOT;
    if (shotMode) {
        win.webContents.on('console-message', (e, level, message) => {
            if (shotMode === 'probe' ? level >= 1 : level >= 2) {
                console.log('PAGE console:', String(message).slice(0, 300));
            }
        });
        win.webContents.once('did-finish-load', () => {
            console.log('LOADED');
            setTimeout(() => app.quit(), parseInt(process.env.GAME_SHOT_DELAY || '2600', 10) + 12000);
            setTimeout(() => {
                win.webContents.executeJavaScript('2 + 2')
                    .then(r => { console.log('EVAL OK', r); return win.webContents.executeJavaScript(
                        "(function(){try{localStorage.setItem('__probe','ok');return 'storage:'+localStorage.getItem('__probe');}catch(e){return 'storage:ERR '+(e&&e.message);}})()"
                    ); })
                    .then(r => {
                        console.log('PROBE', r);
                        if (shotMode === 'probe') { win.destroy(); app.quit(); return null; }
                        return win.webContents.capturePage();
                    }).then(img => {
                        if (!img) return;
                        try {
                            console.log('CAPTURE', JSON.stringify(img.getSize()), 'empty:', img.isEmpty());
                            fs.writeFileSync(shotMode, img.toPNG());
                        } catch (e) { console.log('CAPTURE ERR', e.message); }
                        win.destroy();
                        app.quit();
                    }).catch(err => { console.log('CAPTURE FAIL', err.message); app.quit(); });
            }, parseInt(process.env.GAME_SHOT_DELAY || '2600', 10));
        });
    }

    win.once('ready-to-show', () => win.show());
    if (eballBackend) {
        const params = ['backend=' + eballBackend];
        if (gooseMs !== null) params.push('goose=' + gooseMs);
        win.loadFile('index.html', { search: params.join('&') });
    } else {
        win.loadFile('index.html');
    }

    win.webContents.on('before-input-event', (e, input) => {
        if (input.type === 'keyDown' && input.key === 'F11') {
            e.preventDefault();
            win.setFullScreen(!win.isFullScreen());
        }
    });
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
