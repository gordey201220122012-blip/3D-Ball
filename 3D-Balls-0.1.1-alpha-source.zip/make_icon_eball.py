#!/usr/bin/env python3
"""E-Ball: из icon_src.png делает фиолетовую иконку (hue-shift синего неона)
-> icon_eball.ico, icon_eball_256.png, favicon_eball.png"""
from PIL import Image
import os

SRC = '/home/z/my-project/work/app/icon_src.png'
OUT = '/home/z/my-project/work/app'
HUE_SHIFT = 50   # синий неон -> фиолетовый (экспериментальная сборка)

img = Image.open(SRC).convert('RGBA')
w, h = img.size
side = min(w, h)
img = img.crop(((w - side) // 2, (h - side) // 2, (w + side) // 2, (h + side) // 2))

alpha = img.getchannel('A')
hsv = img.convert('RGB').convert('HSV')
r, g, b = hsv.split()
r = r.point(lambda v: (v + HUE_SHIFT) % 256)
shifted = Image.merge('HSV', (r, g, b)).convert('RGB')
result = shifted.copy()
result.putalpha(alpha)

sizes = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
result.save(os.path.join(OUT, 'icon_eball.ico'), sizes=sizes)
result.resize((256, 256), Image.LANCZOS).save(os.path.join(OUT, 'icon_eball_256.png'))
result.resize((64, 64), Image.LANCZOS).save(os.path.join(OUT, 'favicon_eball.png'))

print('icon_eball.ico:', os.path.getsize(os.path.join(OUT, 'icon_eball.ico')), 'bytes')
print('icon_eball_256.png:', os.path.getsize(os.path.join(OUT, 'icon_eball_256.png')), 'bytes')
print('favicon_eball.png:', os.path.getsize(os.path.join(OUT, 'favicon_eball.png')), 'bytes')
