#!/usr/bin/env python3
"""Из icon_src.png делает icon.ico (мультиразмер), icon_256.png и favicon.png"""
from PIL import Image
import os

SRC = '/home/z/my-project/work/app/icon_src.png'
OUT = '/home/z/my-project/work/app'

img = Image.open(SRC).convert('RGBA')
w, h = img.size
side = min(w, h)
img = img.crop(((w - side) // 2, (h - side) // 2, (w + side) // 2, (h + side) // 2))

# Основные размеры иконки
sizes = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
img.save(os.path.join(OUT, 'icon.ico'), sizes=sizes)
img.resize((256, 256), Image.LANCZOS).save(os.path.join(OUT, 'icon_256.png'))
img.resize((64, 64), Image.LANCZOS).save(os.path.join(OUT, 'favicon.png'))

print('icon.ico:', os.path.getsize(os.path.join(OUT, 'icon.ico')), 'bytes')
print('icon_256.png:', os.path.getsize(os.path.join(OUT, 'icon_256.png')), 'bytes')
print('favicon.png:', os.path.getsize(os.path.join(OUT, 'favicon.png')), 'bytes')
