#!/usr/bin/env python3
"""Сборка 3D Balls / E-Ball:
1. Склеивает src/parts/*.js -> src/game.js
2. Запускает esbuild -> build/bundle.js
3. Склеивает src/html/h*.html, инлайнит шрифты/фавиконку/бандл -> dist/<variant>/index.html
4. Кладёт в dist/<variant>: main.js, package.json, иконки

Варианты:
  python3 build_game.py          — основная сборка 3D Balls  -> dist/app
  python3 build_game.py eball    — экспериментальная E-Ball  -> dist/eball-app
"""
import base64, json, os, subprocess, shutil, sys

ROOT = '/home/z/my-project/work/app'
PARTS = ['p1_core.js', 'p2_ui.js', 'p3_scene.js', 'p4_gameplay.js', 'p5_flow.js']
HTML_PARTS = ['h1.html', 'h2.html', 'h3.html']

variant = sys.argv[1] if len(sys.argv) > 1 else 'main'
IS_EBALL = (variant == 'eball')
DIST = os.path.join(ROOT, 'dist', 'eball-app' if IS_EBALL else 'app')

os.makedirs(os.path.join(ROOT, 'build'), exist_ok=True)
os.makedirs(DIST, exist_ok=True)

# 1. game.js (единый для обоих вариантов; различия включает флаг __EBALL__)
js = []
for p in PARTS:
    with open(os.path.join(ROOT, 'src', 'parts', p), encoding='utf-8') as f:
        js.append(f.read().rstrip() + '\n')
game_js = '\n'.join(js)
with open(os.path.join(ROOT, 'src', 'game.js'), 'w', encoding='utf-8') as f:
    f.write(game_js)
print('game.js:', len(game_js), 'chars')

# 2. esbuild
esbuild = os.path.join(ROOT, 'node_modules', '.bin', 'esbuild')
cmd = [esbuild, os.path.join(ROOT, 'src', 'game.js'), '--bundle', '--format=iife',
       '--platform=browser', '--target=es2019', '--minify', '--charset=utf8',
       '--outfile=' + os.path.join(ROOT, 'build', 'bundle.js')]
r = subprocess.run(cmd, capture_output=True, text=True)
if r.returncode != 0:
    print('ESBUILD FAILED:\n', r.stdout, r.stderr)
    sys.exit(1)
if r.stderr.strip():
    print('esbuild warnings:', r.stderr[:2000])
with open(os.path.join(ROOT, 'build', 'bundle.js'), encoding='utf-8') as f:
    bundle = f.read()
print('bundle.js:', len(bundle), 'chars')

# 3. Шрифты -> @font-face с base64
manifest = json.load(open(os.path.join(ROOT, 'fonts', 'manifest.json')))
faces = []
for m in manifest:
    data = open(os.path.join(ROOT, 'fonts', m['file']), 'rb').read()
    b64 = base64.b64encode(data).decode('ascii')
    faces.append(
        "@font-face{font-family:'%s';font-style:normal;font-weight:%s;font-display:swap;"
        "src:url(data:font/woff2;base64,%s) format('woff2');unicode-range:%s;}"
        % (m['family'], m['weight'], b64, m['unicode_range'])
    )
font_css = '\n'.join(faces)
print('font faces:', len(faces), 'css chars:', len(font_css))

favicon_name = 'favicon_eball.png' if IS_EBALL else 'favicon.png'
if not os.path.exists(os.path.join(ROOT, favicon_name)):
    favicon_name = 'favicon.png'
favicon_b64 = base64.b64encode(open(os.path.join(ROOT, favicon_name), 'rb').read()).decode('ascii')

# 4. index.html
html = ''
for h in HTML_PARTS:
    with open(os.path.join(ROOT, 'src', 'html', h), encoding='utf-8') as f:
        html += f.read()
if IS_EBALL:
    html = html.replace('{{EBALL_HEAD}}', '<script>window.__EBALL__=true</script>')
    html = html.replace('<title>3D Balls</title>', '<title>E-Ball</title>')
else:
    html = html.replace('{{EBALL_HEAD}}', '')
html = html.replace('{{FONT_FACES}}', font_css)
html = html.replace('{{FAVICON}}', favicon_b64)
html = html.replace('{{GAME_SCRIPT}}', '<script>\n' + bundle + '\n</script>')
with open(os.path.join(DIST, 'index.html'), 'w', encoding='utf-8') as f:
    f.write(html)
print('index.html:', len(html), 'chars')

# 5. Файлы приложения
shutil.copy(os.path.join(ROOT, 'main.js'), os.path.join(DIST, 'main.js'))
icon_ico = 'icon_eball.ico' if IS_EBALL else 'icon.ico'
icon_png = 'icon_eball_256.png' if IS_EBALL else 'icon_256.png'
if not os.path.exists(os.path.join(ROOT, icon_ico)):
    icon_ico, icon_png = 'icon.ico', 'icon_256.png'
shutil.copy(os.path.join(ROOT, icon_ico), os.path.join(DIST, 'icon.ico'))
shutil.copy(os.path.join(ROOT, icon_png), os.path.join(DIST, 'icon_256.png'))
pkg = {
    'name': 'e-ball' if IS_EBALL else '3d-balls',
    'productName': 'E-Ball' if IS_EBALL else '3D Balls',
    'version': '0.1.1-alpha',
    'description': ('E-Ball - experimental Vulkan build of 3D Balls (Windows 10+)'
                    if IS_EBALL else
                    '3D Balls - arcade ball-popping shooter for Windows'),
    'main': 'main.js',
    'author': '3D Balls',
    'license': 'MIT'
}
with open(os.path.join(DIST, 'package.json'), 'w', encoding='utf-8') as f:
    json.dump(pkg, f, indent=2)

print('OK [%s] ->' % variant, DIST)
